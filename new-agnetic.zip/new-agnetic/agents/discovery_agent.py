from typing import TypedDict, Dict, Any
from agents.tools.tag_column_tool import tag_columns_tool
import json

# Define state
class AgentState(TypedDict):
    new_schema: Dict[str, Any]
    file: str
    changes: Dict[str, Any]
    tags: str
    last_action: str
    decision: str
    human_approved: bool
    integration_log: list

def discovery_agent(state: AgentState) -> AgentState:
    try:
        changes = state.get("changes", {})
        added_fields = changes.get("added", [])
        if not added_fields:
            print("[Discovery Agent] No added fields, ending workflow")
            state["decision"] = "end"
            return state

        tags = tag_columns_tool(added_fields)
        print(f"[Discovery Agent] Suggested Tags:\n{tags}")
        state["tags"] = tags
        state["last_action"] = "discovery_done"
        return state
    except Exception as e:
        print(f"[Discovery Agent] Error: {str(e)}")
        state["decision"] = "end"
        state["last_action"] = "error"
        return state