from typing import TypedDict, Dict, Any, List
import json
import re
from datetime import datetime, timezone
import os
from openmetadata_ingestion.api.client import OpenMetadata
from openmetadata_ingestion.api.models import Entity
from openmetadata_ingestion.generated.schema.entity.data.table import Table
from openmetadata_ingestion.generated.schema.type.tag_label import TagLabel, LabelType, Source
from config import OPENMETADATA_HOST, OPENMETADATA_TOKEN, OPENMETADATA_SERVICE_NAME, HIVE_DATABASE, INTEGRATION_LOG

# Define state
class AgentState(TypedDict):
    new_schema: Dict[str, Any]
    file: str  # Represents table name for Hive
    changes: Dict[str, Any]
    tags: str
    last_action: str
    decision: str
    human_approved: bool
    integration_log: list

# Initialize OpenMetadata client
openmetadata_client = OpenMetadata(
    config={"host": OPENMETADATA_HOST, "auth_token": lambda: OPENMETADATA_TOKEN}
)

def load_json(path: str, default: Any) -> Any:
    try:
        if os.path.exists(path):
            with open(path) as f:
                data = json.load(f)
                print(f"[Integration Agent] Loaded JSON from {path}: {data}")
                return data
        print(f"[Integration Agent] No JSON file at {path}, using default: {default}")
        return default
    except Exception as e:
        print(f"[Integration Agent] Failed to load JSON from {path}: {str(e)}")
        return default

def save_json(path: str, data: Any) -> None:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"[Integration Agent] Saved JSON to {path}")
    except Exception as e:
        print(f"[Integration Agent] Failed to save JSON to {path}: {str(e)}")

def convert_to_openmetadata_schema(hive_schema: Dict[str, Any]) -> List[Dict]:
    """Convert Hive schema to OpenMetadata column format."""
    columns = []
    for field in hive_schema.get("fields", []):
        hive_type = field["type"].upper()
        om_type = {
            "STRING": "STRING",
            "INT": "INTEGER",
            "DOUBLE": "DOUBLE",
            "TIMESTAMP": "TIMESTAMP",
            "BOOLEAN": "BOOLEAN"
        }.get(hive_type, "STRING")  # Default to STRING for unsupported types
        column = {
            "name": field["name"],
            "dataType": om_type,
            "dataTypeDisplay": field["type"],
            "nullable": True  # Hive fields are typically nullable
        }
        columns.append(column)
    return columns

def update_openmetadata_table(state: AgentState) -> bool:
    """Update OpenMetadata Hive table with schema, tags, and description."""
    try:
        table_name = state["file"]  # Table name in Hive
        fully_qualified_name = f"{OPENMETADATA_SERVICE_NAME}.{HIVE_DATABASE}.{table_name}"

        # Fetch existing table entity
        table_entity: Entity[Table] = openmetadata_client.get_by_name(
            entity=Table, fqn=fully_qualified_name, fields=["columns", "tags", "description"]
        )
        if not table_entity:
            print(f"[Integration Agent] Table {fully_qualified_name} not found in OpenMetadata")
            return False

        # Prepare updates
        updates = {}
        
        # Update schema
        if state["new_schema"]:
            updates["columns"] = convert_to_openmetadata_schema(state["new_schema"])
        
        # Update tags
        if state["tags"]:
            tags = json.loads(re.sub(r'^```json\n|\n```$', '', state["tags"]).strip())
            updates["tags"] = [
                TagLabel(
                    tagFQN=tag["tag"],
                    source=Source.Tag,
                    labelType=LabelType.Automated
                ) for tag in tags
            ]
        
        # Update description (if provided in changes or as a default)
        if state["changes"].get("description"):
            updates["description"] = state["changes"]["description"]
        else:
            updates["description"] = f"Updated Hive table {table_name} with new schema and tags."

        # Patch table in OpenMetadata
        updated_entity = openmetadata_client.patch(
            entity=Table,
            entity_id=table_entity.id,
            data=updates
        )
        if updated_entity:
            print(f"[Integration Agent] Successfully updated table {fully_qualified_name} in OpenMetadata")
            return True
        else:
            print(f"[Integration Agent] Failed to update table {fully_qualified_name}")
            return False
    except Exception as e:
        print(f"[Integration Agent] Error updating OpenMetadata: {str(e)}")
        return False

def integration_agent(state: AgentState) -> AgentState:
    try:
        # Check if human approval is granted
        if not state.get("human_approved", False):
            print("[Integration Agent] Human approval not granted, skipping OpenMetadata update")
            state["decision"] = "end"
            state["last_action"] = "skipped_no_approval"
            return state

        # Strip Markdown code fences from tags if present
        tags = re.sub(r'^```json\n|\n```$', '', state["tags"]).strip()
        
        # Update OpenMetadata
        update_success = update_openmetadata_table(state)
        
        # Log the integration action
        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "table": state["file"],
            "changes": state["changes"],
            "tags": json.loads(tags),
            "status": "applied" if update_success else "failed",
            "openmetadata_updated": update_success
        }
        
        logs = load_json(INTEGRATION_LOG, [])
        logs.append(log_entry)
        save_json(INTEGRATION_LOG, logs)
        
        print(f"[Integration Agent] Processed changes for {state['file']}")
        state["integration_log"] = logs
        state["decision"] = "end"
        state["last_action"] = "integration_done" if update_success else "integration_failed"
        return state
    except Exception as e:
        print(f"[Integration Agent] Error: {str(e)}")
        state["decision"] = "end"
        state["last_action"] = "error"
        return state