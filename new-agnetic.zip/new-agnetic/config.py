import os

# Hive connection settings
HIVE_HOST = os.getenv("HIVE_HOST", "localhost")
HIVE_PORT = os.getenv("HIVE_PORT", "10000")
HIVE_DATABASE = os.getenv("HIVE_DATABASE", "default")
HIVE_USER = os.getenv("HIVE_USER", "hive")
HIVE_PASSWORD = os.getenv("HIVE_PASSWORD", "")

# OpenMetadata settings
OPENMETADATA_HOST = os.getenv("OPENMETADATA_HOST", "http://127.0.0.1:8585")
OPENMETADATA_TOKEN = os.getenv("OPENMETADATA_TOKEN", "eyJraWQiOiJHYjM4OWEtOWY3Ni1nZGpzLWE5MmotMDI0MmJrOTQzNTYiLCJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJvcGVuLW1ldGFkYXRhLm9yZyIsInN1YiI6ImFkbWluIiwicm9sZXMiOlsiQWRtaW4iXSwiZW1haWwiOiJhZG1pbkBvcGVuLW1ldGFkYXRhLm9yZyIsImlzQm90IjpmYWxzZSwidG9rZW5UeXBlIjoiUEVSU09OQUxfQUNDRVNTIiwiaWF0IjoxNzUxODg0NDQwLCJleHAiOjE3NTI0ODkyNDB9.dL3iRqNJMcSr50CUR8Xb50hfZuh5WWpY2HgMIunJeYq7F865EtH3NGKRj7yjBGQkkqt3B3Ac_c3LkndxCOgkP-DevTWJmAGgsISWKAdGf9mKQ-Zp1rYxJk1JjlMDX5CCkXjjiXj06nP9WmG0BSdqrDlXxrAV5q97p0AQVRChAkakizaODxmgBoe-eLb5NbaiZGrPZI52z42AWe9ZmofNiVDLFCWPMqprw96yHHFQ7T7B2LuTJ5FBreWdRvW0lhk_oLwQKvmcA5NvEM7ZW1jiIw3uRv-Y47uiMVGWOejHmNUbevfS__uCqHYjYYdzY1Oo1YmIjN5YVJ8Ax4jToyxpQwA")
OPENMETADATA_SERVICE_NAME = os.getenv("OPENMETADATA_SERVICE_NAME", "hive_service")  # Hive service in OpenMetadata

# Log file paths
SCHEMA_CACHE = "logs/schema_cache.json"
CHANGE_LOG = "logs/change_log.json"
INTEGRATION_LOG = "logs/integration_log.json"