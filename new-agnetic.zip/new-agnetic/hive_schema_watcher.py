import os
import json
from datetime import datetime, timezone
from pyhive import hive
from config import HIVE_HOST, HIVE_PORT, HIVE_DATABASE, HIVE_USER, HIVE_PASSWORD, SCHEMA_CACHE, CHANGE_LOG

def get_hive_connection():
    try:
        conn = hive.connect(
            host=HIVE_HOST,
            port=int(HIVE_PORT),
            database=HIVE_DATABASE,
            username=HIVE_USER,
            password=HIVE_PASSWORD
        )
        print("[Hive Schema Watcher] Successfully connected to Hive metastore")
        return conn
    except Exception as e:
        print(f"[Hive Schema Watcher] Failed to connect to Hive: {str(e)}")
        raise

def list_hive_tables():
    try:
        conn = get_hive_connection()
        cursor = conn.cursor()
        cursor.execute(f"SHOW TABLES IN {HIVE_DATABASE}")
        tables = [row[0] for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        print(f"[Hive Schema Watcher] Found {len(tables)} tables: {tables}")
        return tables
    except Exception as e:
        print(f"[Hive Schema Watcher] Error listing tables: {str(e)}")
        return []

def get_table_schema(table_name):
    try:
        conn = get_hive_connection()
        cursor = conn.cursor()
        cursor.execute(f"DESCRIBE {HIVE_DATABASE}.{table_name}")
        schema = {"fields": [{"name": row[0], "type": row[1]} for row in cursor.fetchall()]}
        cursor.close()
        conn.close()
        print(f"[Hive Schema Watcher] Extracted schema for {table_name}: {schema}")
        return schema
    except Exception as e:
        print(f"[Hive Schema Watcher] Error extracting schema for {table_name}: {str(e)}")
        raise

def compare_schemas(old, new):
    old_f = set((f["name"], f["type"]) for f in old["fields"])
    new_f = set((f["name"], f["type"]) for f in new["fields"])
    added = [{"name": n, "type": t} for n, t in new_f - old_f]
    removed = [{"name": n, "type": t} for n, t in old_f - new_f]
    modified = [{"name": n, "old_type": old_f[n], "new_type": new_f[n]} for n in old_f if n in new_f and old_f[n] != new_f[n]]
    changes = {"added": added, "removed": removed, "modified": modified}
    print(f"[Hive Schema Watcher] Schema changes detected: {changes}")
    return changes

def load_json(path, default):
    try:
        if os.path.exists(path):
            with open(path) as f:
                data = json.load(f)
                print(f"[Hive Schema Watcher] Loaded JSON from {path}: {data}")
                return data
        print(f"[Hive Schema Watcher] No JSON file at {path}, using default: {default}")
        return default
    except Exception as e:
        print(f"[Hive Schema Watcher] Error loading JSON from {path}: {str(e)}")
        return default

def save_json(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"[Hive Schema Watcher] Saved JSON to {path}")
    except Exception as e:
        print(f"[Hive Schema Watcher] Error saving JSON to {path}: {str(e)}")

def get_schema_state(_):
    try:
        os.makedirs("logs", exist_ok=True)
        old_schema = load_json(SCHEMA_CACHE, {"fields": []})
        tables = list_hive_tables()
        processed = {entry["table"] for entry in load_json(CHANGE_LOG, [])}

        if not tables:
            print("[Hive Schema Watcher] No tables found in database, ending workflow")
            return {"decision": "end"}

        for table in tables:
            if table in processed:
                print(f"[Hive Schema Watcher] Skipping processed table: {table}")
                continue
            new_schema = get_table_schema(table)
            changes = compare_schemas(old_schema, new_schema)
            if changes["added"] or changes["removed"] or changes["modified"]:
                save_json(SCHEMA_CACHE, new_schema)
                log = load_json(CHANGE_LOG, [])
                log.append({
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "table": table,
                    "changes": changes
                })
                save_json(CHANGE_LOG, log)
                print(f"[Hive Schema Watcher] Detected changes in {table}, proceeding to supervisor")
                return {"new_schema": new_schema, "file": table, "changes": changes, "decision": None}
            else:
                print(f"[Hive Schema Watcher] No schema changes in {table}")
        print("[Hive Schema Watcher] No new schema changes detected, ending workflow")
        return {"decision": "end"}
    except Exception as e:
        print(f"[Hive Schema Watcher] Error in schema watching: {str(e)}")
        return {"decision": "end"}