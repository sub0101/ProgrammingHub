from dotenv import load_dotenv
load_dotenv()

from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableLambda
from agents.supervisor_agent import supervisor_agent
from agents.discovery_agent import discovery_agent
from agents.integration_agent import integration_agent
from minio_watcher.schema_watcher import get_schema_state
from typing import TypedDict, Optional, List, Dict, Any

class SchemaState(TypedDict):
    new_schema: Optional[Dict[str, Any]]
    file: Optional[str]
    changes: Optional[Dict[str, List[Dict[str, str]]]]
    decision: Optional[str]
    tags: Optional[str]

workflow = StateGraph(SchemaState)
workflow.add_node("CheckSchema", RunnableLambda(get_schema_state))
workflow.add_node("Supervisor", RunnableLambda(supervisor_agent))
workflow.add_node("Discovery", RunnableLambda(discovery_agent))
workflow.add_node("Integration", RunnableLambda(integration_agent))

workflow.set_entry_point("CheckSchema")

workflow.add_edge("CheckSchema", "Supervisor")

workflow.add_conditional_edges(
    "Supervisor",
    lambda x: x["decision"],
    {
        "discovery": "Discovery",
        "integration": "Integration",
        "end": END
    }
)

workflow.add_edge("Discovery", "Supervisor")
workflow.add_edge("Integration", END)

graph = workflow.compile()

if __name__ == "__main__":
    result = graph.invoke({})
    print("[FINAL RESULT]", result)
