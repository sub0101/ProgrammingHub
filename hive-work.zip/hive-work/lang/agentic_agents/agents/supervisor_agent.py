# import os
# import json
# from typing import TypedDict, Dict, Any
# from langchain_google_genai import ChatGoogleGenerativeAI
# from langchain.prompts import ChatPromptTemplate
# from dotenv import load_dotenv

# # Load environment variables
# load_dotenv()

# # Define state
# class AgentState(TypedDict):
#     new_schema: Dict[str, Any]
#     file: str
#     changes: Dict[str, Any]
#     tags: str
#     last_action: str
#     decision: str
#     human_approved: bool
#     integration_log: list

# # Initialize LLM
# try:
#     google_api_key = os.getenv("GOOGLE_API_KEY")
#     if not google_api_key:
#         raise ValueError("GOOGLE_API_KEY not found in environment variables")
#     print(f"[Supervisor Agent] Using GOOGLE_API_KEY: {google_api_key[:4]}****")
    
#     llm = ChatGoogleGenerativeAI(
#         model="gemini-2.5-flash",
#         google_api_key=google_api_key,
#         temperature=0,
#     )
# except Exception as e:
#     print(f"[Supervisor Agent] Failed to initialize LLM: {str(e)}")
#     raise

# def supervisor_agent(state: AgentState) -> AgentState:
#     try:
#         if state.get("decision") == "end":
#             print("[Supervisor Agent] Decision: end (no further action)")
#             return state

#         # Define prompt based on state
#         if state.get("last_action") == "discovery_done":
#             prompt = ChatPromptTemplate.from_template("""
# You are a supervisor agent managing schema changes. The metadata tagging is complete for file {file}:
# {tags}

# Return a JSON object indicating the next action:
# {{
#   "decision": "integration" | "discovery" | "end",
#   "reason": "string"
# }}

# Choose "integration" to apply tags, "discovery" to retry tagging, or "end" to exit.
# Ensure the response is valid JSON.
#             """)
#             input_text = prompt.format(file=state["file"], tags=state["tags"])
#         else:
#             prompt = ChatPromptTemplate.from_template("""
# You are a supervisor agent managing schema changes. Schema changes detected for file {file}:
# {changes}

# Return a JSON object indicating the next action:
# {{
#   "decision": "discovery" | "integration" | "end",
#   "reason": "string"
# }}

# Choose "discovery" to suggest metadata tags, "integration" to apply changes, or "end" to exit.
# Ensure the response is valid JSON.
#             """)
#             input_text = prompt.format(file=state["file"], changes=json.dumps(state["changes"], indent=2))

#         # Invoke LLM and log raw response
#         print(f"[Supervisor Agent] Sending prompt:\n{input_text}")
#         response = llm.invoke(input_text).content.strip()
#         print(f"[Supervisor Agent] Raw LLM response:\n{response}")

#         # Validate and parse response
#         if not response:
#             print("[Supervisor Agent] Error: Empty response from LLM")
#             state["decision"] = "end"
#             state["last_action"] = "error"
#             return state

#         try:
#             decision_data = json.loads(response)
#             if not isinstance(decision_data, dict) or "decision" not in decision_data or "reason" not in decision_data:
#                 raise ValueError("Invalid JSON structure: missing 'decision' or 'reason'")
#             if decision_data["decision"] not in ["discovery", "integration", "end"]:
#                 raise ValueError(f"Invalid decision value: {decision_data['decision']}")
#         except json.JSONDecodeError as e:
#             print(f"[Supervisor Agent] JSON parsing error: {str(e)}")
#             print(f"[Supervisor Agent] Attempting to fix response: {response}")
#             # Fallback: assume discovery for new changes
#             decision_data = {"decision": "discovery", "reason": "Fallback due to invalid LLM response"}
#         except ValueError as e:
#             print(f"[Supervisor Agent] Validation error: {str(e)}")
#             decision_data = {"decision": "end", "reason": f"Invalid response: {str(e)}"}

#         print(f"[Supervisor Agent] Decision: {decision_data}")
#         state["decision"] = decision_data["decision"]
#         state["last_action"] = "supervisor_decided"
#         return state
#     except Exception as e:
#         print(f"[Supervisor Agent] Unexpected error: {str(e)}")
#         state["decision"] = "end"
#         state["last_action"] = "error"
#         return state

import os
import json
import re
from typing import TypedDict, Dict, Any
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Define state
class AgentState(TypedDict):
    new_schema: Dict[str, Any]
    file: str
    changes: Dict[str, Any]
    tags: str
    last_action: str
    decision: str
    human_approved: bool
    integration_log: list

# Initialize LLM
try:
    google_api_key = os.getenv("GOOGLE_API_KEY")
    if not google_api_key:
        raise ValueError("GOOGLE_API_KEY not found in environment variables")
    print(f"[Supervisor Agent] Using GOOGLE_API_KEY: {google_api_key[:4]}****")
    
    llm = ChatGoogleGenerativeAI(
        model="gemini-1.5-flash",
        google_api_key=google_api_key,
        temperature=0,
    )
except Exception as e:
    print(f"[Supervisor Agent] Failed to initialize LLM: {str(e)}")
    raise

def supervisor_agent(state: AgentState) -> AgentState:
    try:
        if state.get("decision") == "end":
            print("[Supervisor Agent] Decision: end (no further action)")
            return state

        # Define prompt based on state
        if state.get("last_action") == "discovery_done":
            prompt = ChatPromptTemplate.from_template("""
You are a supervisor agent managing schema changes. The metadata tagging is complete for file {file}:
{tags}

Return a JSON object indicating the next action:
{{
  "decision": "integration" | "discovery" | "end",
  "reason": "string"
}}

Choose "integration" to apply tags, "discovery" to retry tagging, or "end" to exit.
Ensure the response is valid JSON without Markdown code fences.
            """)
            input_text = prompt.format(file=state["file"], tags=state["tags"])
        else:
            prompt = ChatPromptTemplate.from_template("""
You are a supervisor agent managing schema changes. Schema changes detected for file {file}:
{changes}

Return a JSON object indicating the next action:
{{
  "decision": "discovery" | "integration" | "end",
  "reason": "string"
}}

Choose "discovery" to suggest metadata tags, "integration" to apply changes, or "end" to exit.
Ensure the response is valid JSON without Markdown code fences.
            """)
            input_text = prompt.format(file=state["file"], changes=json.dumps(state["changes"], indent=2))

        # Invoke LLM and log raw response
        print(f"[Supervisor Agent] Sending prompt:\n{input_text}")
        response = llm.invoke(input_text).content.strip()
        print(f"[Supervisor Agent] Raw LLM response:\n{response}")

        # Strip Markdown code fences if present
        response = re.sub(r'^```json\n|\n```$', '', response).strip()
        
        # Validate and parse response
        if not response:
            print("[Supervisor Agent] Error: Empty response from LLM")
            state["decision"] = "end"
            state["last_action"] = "error"
            return state

        try:
            decision_data = json.loads(response)
            if not isinstance(decision_data, dict) or "decision" not in decision_data or "reason" not in decision_data:
                raise ValueError("Invalid JSON structure: missing 'decision' or 'reason'")
            if decision_data["decision"] not in ["discovery", "integration", "end"]:
                raise ValueError(f"Invalid decision value: {decision_data['decision']}")
        except json.JSONDecodeError as e:
            print(f"[Supervisor Agent] JSON parsing error: {str(e)}")
            print(f"[Supervisor Agent] Attempting to fix response: {response}")
            # Fallback: assume discovery for new changes
            decision_data = {"decision": "discovery", "reason": "Fallback due to invalid LLM response"}
        except ValueError as e:
            print(f"[Supervisor Agent] Validation error: {str(e)}")
            decision_data = {"decision": "end", "reason": f"Invalid response: {str(e)}"}

        print(f"[Supervisor Agent] Decision: {decision_data}")
        state["decision"] = decision_data["decision"]
        state["last_action"] = "supervisor_decided"
        return state
    except Exception as e:
        print(f"[Supervisor Agent] Unexpected error: {str(e)}")
        state["decision"] = "end"
        state["last_action"] = "error"
        return state