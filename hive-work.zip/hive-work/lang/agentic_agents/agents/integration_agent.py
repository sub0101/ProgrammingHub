# from typing import TypedDict, Dict, Any
# import json
# import re
# from datetime import datetime, timezone
# import os
# # Define state
# class AgentState(TypedDict):
#     new_schema: Dict[str, Any]
#     file: str
#     changes: Dict[str, Any]
#     tags: str
#     last_action: str
#     decision: str
#     human_approved: bool
#     integration_log: list

# def load_json(path: str, default: Any) -> Any:
#     try:
#         if os.path.exists(path):
#             with open(path) as f:
#                 data = json.load(f)
#                 print(f"[Integration Agent] Loaded JSON from {path}: {data}")
#                 return data
#         print(f"[Integration Agent] No JSON file at {path}, using default: {default}")
#         return default
#     except Exception as e:
#         print(f"[Integration Agent] Failed to load JSON from {path}: {str(e)}")
#         return default

# def save_json(path: str, data: Any) -> None:
#     try:
#         with open(path, 'w') as f:
#             json.dump(data, f, indent=2)
#         print(f"[Integration Agent] Saved JSON to {path}")
#     except Exception as e:
#         print(f"[Integration Agent] Failed to save JSON to {path}: {str(e)}")

# def integration_agent(state: AgentState) -> AgentState:
#     try:
#         # Strip Markdown code fences from tags if present
#         tags = re.sub(r'^```json\n|\n```$', '', state["tags"]).strip()
        
#         log_entry = {
#             "timestamp": datetime.now(timezone.utc).isoformat(),
#             "file": state["file"],
#             "changes": state["changes"],
#             "tags": json.loads(tags),  # Parse cleaned tags
#             "status": "applied"
#         }
        
#         log_file = "logs/integration_log.json"
#         logs = load_json(log_file, [])
#         logs.append(log_entry)
#         save_json(log_file, logs)
        
#         print(f"[Integration Agent] Logged changes for {state['file']}")
#         state["integration_log"] = logs
#         state["decision"] = "end"
#         state["last_action"] = "integration_done"
#         return state
#     except Exception as e:
#         print(f"[Integration Agent] Error: {str(e)}")
#         state["decision"] = "end"
#         state["last_action"] = "error"
#         return state

from typing import TypedDict, Dict, Any, List
import json
import re
from datetime import datetime, timezone
import os
from openmetadata_ingestion.api.client import OpenMetadata
from openmetadata_ingestion.api.models import Entity
from openmetadata_ingestion.generated.schema.entity.data.table import Table
from openmetadata_ingestion.generated.schema.type.tag_label import TagLabel, LabelType, Source

# Define state
class AgentState(TypedDict):
    new_schema: Dict[str, Any]
    file: str
    changes: Dict[str, Any]
    tags: str
    last_action: str
    decision: str
    human_approved: bool
    integration_log: list

# OpenMetadata configuration
OPENMETADATA_HOST = os.getenv("OPENMETADATA_HOST", "http://127.0.0.1:8585")
OPENMETADATA_TOKEN = os.getenv("OPENMETADATA_TOKEN", "eyJraWQiOiJHYjM4OWEtOWY3Ni1nZGpzLWE5MmotMDI0MmJrOTQzNTYiLCJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJvcGVuLW1ldGFkYXRhLm9yZyIsInN1YiI6ImFkbWluIiwicm9sZXMiOlsiQWRtaW4iXSwiZW1haWwiOiJhZG1pbkBvcGVuLW1ldGFkYXRhLm9yZyIsImlzQm90IjpmYWxzZSwidG9rZW5UeXBlIjoiUEVSU09OQUxfQUNDRVNTIiwiaWF0IjoxNzUxODg0NDQwLCJleHAiOjE3NTI0ODkyNDB9.dL3iRqNJMcSr50CUR8Xb50hfZuh5WWpY2HgMIunJeYq7F865EtH3NGKRj7yjBGQkkqt3B3Ac_c3LkndxCOgkP-DevTWJmAGgsISWKAdGf9mKQ-Zp1rYxJk1JjlMDX5CCkXjjXj06nP9WmG0BSdqrDlXxrAV5q97p0AQVRChAkakizaODxmgBoe-eLb5NbaiZGrPZI52z42AWe9ZmofNiVDLFCWPMqprw96yHHFQ7T7B2LuTJ5FBreWdRvW0lhk_oLwQKvmcA5NvEM7ZW1jiIw3uRv-Y47uiMVGWOejHmNUbevfS__uCqHYjYYdzY1Oo1YmIjN5YVJ8Ax4jToyxpQwA")
OPENMETADATA_SERVICE_NAME = "customer_data"  # Name of MinIO storage service in OpenMetadata
OPENMETADATA_DATABASE = "my_bucket"  # Database name in OpenMetadata

# Initialize OpenMetadata client
openmetadata_client = OpenMetadata(
    config={"host": OPENMETADATA_HOST, "auth_token": lambda: OPENMETADATA_TOKEN}
)

def load_json(path: str, default: Any) -> Any:
    try:
        if os.path.exists(path):
            with open(path) as f:
                data = json.load(f)
                print(f"[Integration Agent] Loaded JSON from {path}: {data}")
                return data
        print(f"[Integration Agent] No JSON file at {path}, using default: {default}")
        return default
    except Exception as e:
        print(f"[Integration Agent] Failed to load JSON from {path}: {str(e)}")
        return default

def save_json(path: str, data: Any) -> None:
    try:
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"[Integration Agent] Saved JSON to {path}")
    except Exception as e:
        print(f"[Integration Agent] Failed to save JSON to {path}: {str(e)}")

def convert_to_openmetadata_schema(spark_schema: Dict[str, Any]) -> List[Dict]:
    """Convert Spark schema to OpenMetadata column format."""
    columns = []
    for field in spark_schema.get("fields", []):
        # Map Spark data types to OpenMetadata data types
        spark_type = field["type"].upper()
        # Handle complex types (e.g., struct, array) if needed
        om_type = spark_type if spark_type in ["STRING", "INTEGER", "DOUBLE", "TIMESTAMP", "BOOLEAN"] else "STRING"
        column = {
            "name": field["name"],
            "dataType": om_type,
            "dataTypeDisplay": field["type"],
            "nullable": field.get("nullable", True)
        }
        columns.append(column)
    return columns

def update_openmetadata_table(state: AgentState) -> bool:
    """Update OpenMetadata table with schema, tags, and description."""
    try:
        table_name = os.path.basename(state["file"])  # e.g., userData
        fully_qualified_name = f"{OPENMETADATA_SERVICE_NAME}.{OPENMETADATA_DATABASE}.{table_name}"

        # Fetch existing table entity
        table_entity: Entity[Table] = openmetadata_client.get_by_name(
            entity=Table, fqn=fully_qualified_name, fields=["columns", "tags", "description"]
        )
        if not table_entity:
            print(f"[Integration Agent] Table {fully_qualified_name} not found in OpenMetadata")
            return False

        # Prepare updates
        updates = {}
        
        # Update schema
        if state["new_schema"]:
            updates["columns"] = convert_to_openmetadata_schema(state["new_schema"])
        
        # Update tags
        if state["tags"]:
            tags = json.loads(re.sub(r'^```json\n|\n```$', '', state["tags"]).strip())
            updates["tags"] = [
                TagLabel(
                    tagFQN=tag,
                    source=Source.Tag,
                    labelType=LabelType.Automated
                ) for tag in tags
            ]
        
        # Update description (if provided in changes)
        if state["changes"].get("description"):
            updates["description"] = state["changes"]["description"]

        # Patch table in OpenMetadata
        updated_entity = openmetadata_client.patch(
            entity=Table,
            entity_id=table_entity.id,
            data=updates
        )
        if updated_entity:
            print(f"[Integration Agent] Successfully updated table {fully_qualified_name} in OpenMetadata")
            return True
        else:
            print(f"[Integration Agent] Failed to update table {fully_qualified_name}")
            return False
    except Exception as e:
        print(f"[Integration Agent] Error updating OpenMetadata: {str(e)}")
        return False

def integration_agent(state: AgentState) -> AgentState:
    try:
        # Check if human approval is granted
        if not state.get("human_approved", False):
            print("[Integration Agent] Human approval not granted, skipping OpenMetadata update")
            state["decision"] = "end"
            state["last_action"] = "skipped_no_approval"
            return state

        # Strip Markdown code fences from tags if present
        tags = re.sub(r'^```json\n|\n```$', '', state["tags"]).strip()
        
        # Update OpenMetadata
        update_success = update_openmetadata_table(state)
        
        # Log the integration action
        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "file": state["file"],
            "changes": state["changes"],
            "tags": json.loads(tags),
            "status": "applied" if update_success else "failed",
            "openmetadata_updated": update_success
        }
        
        log_file = "logs/integration_log.json"
        logs = load_json(log_file, [])
        logs.append(log_entry)
        save_json(log_file, logs)
        
        print(f"[Integration Agent] Processed changes for {state['file']}")
        state["integration_log"] = logs
        state["decision"] = "end"
        state["last_action"] = "integration_done" if update_success else "integration_failed"
        return state
    except Exception as e:
        print(f"[Integration Agent] Error: {str(e)}")
        state["decision"] = "end"
        state["last_action"] = "error"
        return state