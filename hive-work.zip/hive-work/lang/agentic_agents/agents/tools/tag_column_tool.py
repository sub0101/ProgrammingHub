import json
import os
import re
from langchain.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize LLM
try:
    google_api_key = os.getenv("GOOGLE_API_KEY")
    if not google_api_key:
        raise ValueError("GOOGLE_API_KEY not found in environment variables")
    print(f"[Tag Column Tool] Using GOOGLE_API_KEY: {google_api_key[:4]}****")
    
    llm = ChatGoogleGenerativeAI(
        model="gemini-1.5-flash",
        google_api_key=google_api_key,
        temperature=0,
    )
except Exception as e:
    print(f"[Tag Column Tool] Failed to initialize LLM: {str(e)}")
    raise

def tag_columns_tool(fields):
    prompt = ChatPromptTemplate.from_template("""
You are a data catalog assistant. Given a list of columns with name and type, return a JSON array with suggested tags and a brief description for each column.

Example output:
[
  {{ "name": "user_id", "tag": "identifier", "description": "Unique ID of the user." }},
  {{ "name": "email", "tag": "PII", "description": "User's email address." }}
]

Input columns:
{fields}

Ensure the response is valid JSON without Markdown code fences or extra characters. Each entry must have "name", "tag", and "description" fields.
    """)
    try:
        input_text = prompt.format(fields=json.dumps(fields, indent=2))
        print(f"[Tag Column Tool] Prompt Sent:\n{input_text}")
        response = llm.invoke(input_text).content.strip()
        print(f"[Tag Column Tool] Raw LLM response:\n{response}")

        # Strip Markdown code fences and other common issues
        response = re.sub(r'^```json\n|\n```$', '', response).strip()
        response = re.sub(r'^```|\n```$', '', response).strip()  # Handle plain ``` fences
        response = response.replace('\n', '').replace('\r', '')  # Remove newlines within JSON

        # Validate JSON
        try:
            tags = json.loads(response)
            if not isinstance(tags, list):
                raise ValueError("Response is not a JSON array")
            for tag in tags:
                if not all(key in tag for key in ["name", "tag", "description"]):
                    raise ValueError(f"Invalid tag structure: {tag}")
            return json.dumps(tags)
        except json.JSONDecodeError as e:
            print(f"[Tag Column Tool] JSON parsing error: {str(e)}")
            print(f"[Tag Column Tool] Invalid response: {response}")
            # Fallback: generate basic tags based on column names and types
            fallback_tags = []
            for field in fields:
                tag = "identifier" if field["name"] in ["id", "user_id"] else "PII" if field["name"] in ["name", "email"] else "general"
                description = f"Field {field['name']} of type {field['type']}."
                fallback_tags.append({
                    "name": field["name"],
                    "tag": tag,
                    "description": description
                })
            print(f"[Tag Column Tool] Using fallback tags: {fallback_tags}")
            return json.dumps(fallback_tags)
        except ValueError as e:
            print(f"[Tag Column Tool] Validation error: {str(e)}")
            return json.dumps([])
    except Exception as e:
        print(f"[Tag Column Tool] Unexpected error: {str(e)}")
        return json.dumps([])