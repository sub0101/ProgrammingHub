import os
import json
from datetime import datetime, timezone
import boto3
from botocore.client import Config
import pyarrow.parquet as pq
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT", "localhost:9000")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY", "mynewaccesskey")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY", "mynewsecretkey")
MINIO_BUCKET = os.getenv("MINIO_BUCKET", "mybucket")
DELTA_PREFIX = os.getenv("DELTA_PREFIX", "")
SCHEMA_CACHE = "logs/schema_cache.json"
CHANGE_LOG = "logs/change_log.json"
LATEST_PARQUET = "logs/latest_schema.parquet"

def get_minio_client():
    try:
        client = boto3.client(
            's3',
            endpoint_url=f"http://{MINIO_ENDPOINT}",
            aws_access_key_id=MINIO_ACCESS_KEY,
            aws_secret_access_key=MINIO_SECRET_KEY,
            config=Config(signature_version='s3v4'),
            region_name='us-east-1'
        )
        # Test bucket access
        client.head_bucket(Bucket=MINIO_BUCKET)
        print("[Schema Watcher] Successfully connected to MinIO and verified bucket")
        return client
    except Exception as e:
        print(f"[Schema Watcher] Failed to connect to MinIO or access bucket {MINIO_BUCKET}: {str(e)}")
        raise

def list_delta_files():
    try:
        client = get_minio_client()
        res = client.list_objects_v2(Bucket=MINIO_BUCKET, Prefix=DELTA_PREFIX)
        files = sorted(
            [(f['Key'], f['LastModified']) for f in res.get('Contents', []) if f['Key'].endswith('.parquet')],
            key=lambda x: x[1]
        )
        print(f"[Schema Watcher] Found {len(files)} Parquet files: {files}")
        return files
    except Exception as e:
        print(f"[Schema Watcher] Error listing files: {str(e)}")
        return []

def download_file(key, path):
    try:
        get_minio_client().download_file(MINIO_BUCKET, key, path)
        print(f"[Schema Watcher] Downloaded file {key} to {path}")
    except Exception as e:
        print(f"[Schema Watcher] Error downloading file {key}: {str(e)}")
        raise

def extract_schema(path):
    try:
        table = pq.read_table(path)
        schema = {"fields": [{"name": f.name, "type": str(f.type)} for f in table.schema]}
        print(f"[Schema Watcher] Extracted schema from {path}: {schema}")
        return schema
    except Exception as e:
        print(f"[Schema Watcher] Error extracting schema from {path}: {str(e)}")
        raise

def compare_schemas(old, new):
    old_f = set((f["name"], f["type"]) for f in old["fields"])
    new_f = set((f["name"], f["type"]) for f in new["fields"])
    added = new_f - old_f
    removed = old_f - new_f
    changes = {
        "added": [dict(zip(["name", "type"], x)) for x in added],
        "removed": [dict(zip(["name", "type"], x)) for x in removed]
    }
    print(f"[Schema Watcher] Schema changes detected: {changes}")
    return changes

def load_json(path, default):
    try:
        if os.path.exists(path):
            with open(path) as f:
                data = json.load(f)
                print(f"[Schema Watcher] Loaded JSON from {path}: {data}")
                return data
        print(f"[Schema Watcher] No JSON file at {path}, using default: {default}")
        return default
    except Exception as e:
        print(f"[Schema Watcher] Error loading JSON from {path}: {str(e)}")
        return default

def save_json(path, data):
    try:
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"[Schema Watcher] Saved JSON to {path}")
    except Exception as e:
        print(f"[Schema Watcher] Error saving JSON to {path}: {str(e)}")

def get_schema_state(_):
    try:
        os.makedirs("logs", exist_ok=True)
        old_schema = load_json(SCHEMA_CACHE, {"fields": []})
        files = list_delta_files()
        processed = {entry["file"] for entry in load_json(CHANGE_LOG, [])}

        if not files:
            print("[Schema Watcher] No Parquet files found in bucket, ending workflow")
            return {"decision": "end"}

        for file, _ in files:
            if file in processed:
                print(f"[Schema Watcher] Skipping processed file: {file}")
                continue
            download_file(file, LATEST_PARQUET)
            new_schema = extract_schema(LATEST_PARQUET)
            changes = compare_schemas(old_schema, new_schema)
            if changes["added"] or changes["removed"]:
                save_json(SCHEMA_CACHE, new_schema)
                log = load_json(CHANGE_LOG, [])
                log.append({
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "file": file,
                    "changes": changes
                })
                save_json(CHANGE_LOG, log)
                print(f"[Schema Watcher] Detected changes in {file}, proceeding to supervisor")
                return {"new_schema": new_schema, "file": file, "changes": changes, "decision": None}
            else:
                print(f"[Schema Watcher] No schema changes in {file}")
        print("[Schema Watcher] No new schema changes detected, ending workflow")
        return {"decision": "end"}
    except Exception as e:
        print(f"[Schema Watcher] Error in schema watching: {str(e)}")
        return {"decision": "end"}