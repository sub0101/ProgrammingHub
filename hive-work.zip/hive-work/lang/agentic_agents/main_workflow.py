from typing import TypedDict, Dict, Any
from langgraph.graph import StateGraph, END
from minio_watcher.schema_watcher import get_schema_state
from agents.supervisor_agent import supervisor_agent
from agents.discovery_agent import discovery_agent
from agents.integration_agent import integration_agent
import json
from dotenv import load_dotenv
import traceback

# Load environment variables
load_dotenv()

# Define state
class AgentState(TypedDict):
    new_schema: Dict[str, Any]
    file: str
    changes: Dict[str, Any]
    tags: str
    last_action: str
    decision: str
    human_approved: bool
    integration_log: list

def human_review(state: AgentState) -> AgentState:
    try:
        print(f"\n[Human Review] Please review the suggested tags for {state['file']}:\n{state['tags']}")
        approval = input("Approve tags? (yes/no): ").lower().strip() == "yes"
        
        state["human_approved"] = approval
        state["decision"] = "integration" if approval else "discovery"
        state["last_action"] = "human_reviewed"
        print(f"[Human Review] Approval: {approval}")
        return state
    except Exception as e:
        print(f"[Human Review] Error: {str(e)}")
        print(traceback.format_exc())
        state["decision"] = "end"
        state["last_action"] = "error"
        return state

# Define the workflow
workflow = StateGraph(AgentState)

# Add nodes
workflow.add_node("schema_watcher", get_schema_state)
workflow.add_node("supervisor", supervisor_agent)
workflow.add_node("discovery", discovery_agent)
workflow.add_node("human_review", human_review)
workflow.add_node("integration", integration_agent)

# Define edges
workflow.set_entry_point("schema_watcher")
workflow.add_conditional_edges(
    "schema_watcher",
    lambda state: state["decision"],
    {
        "end": END,
        None: "supervisor"
    }
)
workflow.add_conditional_edges(
    "supervisor",
    lambda state: state["decision"],
    {
        "discovery": "discovery",
        "integration": "integration",
        "end": END
    }
)
workflow.add_edge("discovery", "human_review")
workflow.add_conditional_edges(
    "human_review",
    lambda state: state["decision"],
    {
        "integration": "integration",
        "discovery": "discovery",
        "end": END
    }
)
workflow.add_edge("integration", END)

# Compile and run
def run_workflow():
    try:
        app = workflow.compile()
        initial_state = {
            "new_schema": {},
            "file": "",
            "changes": {},
            "tags": "",
            "last_action": "",
            "decision": "",
            "human_approved": False,
            "integration_log": []
        }
        
        print("[Workflow] Starting schema change detection...")
        result = app.invoke(initial_state)
        print("[Workflow] Final state:", json.dumps(result, indent=2))
        return result
    except Exception as e:
        print(f"[Workflow] Error: {str(e)}")
        print(f"[Workflow] Stack trace:\n{traceback.format_exc()}")
        return None

if __name__ == "__main__":
    run_workflow()