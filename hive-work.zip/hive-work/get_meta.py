import os
import json
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def get_storage_services(host: str, jwt_token: str) -> list:
    """Retrieve all storage services from OpenMetadata."""
    try:
        headers = {"Authorization": f"Bearer {jwt_token}", "Content-Type": "application/json"}
        response = requests.get(f"{host}/api/v1/services/storageServices", headers=headers, timeout=5)
        response.raise_for_status()
        services = response.json().get("data", [])
        print(f"[OpenMetadata] Found storage services: {[s['name'] for s in services]}")
        return services
    except requests.RequestException as e:
        print(f"[OpenMetadata] Error retrieving storage services: {str(e)}")
        return []

def get_minio_metadata(host: str, jwt_token: str, service_name: str = "minio_storage", output_file: str = "minio_metadata.json"):
    """
    Retrieve metadata for tables derived from MinIO Parquet files in OpenMetadata.
    
    Args:
        host (str): OpenMetadata or MCP server URL (e.g., http://localhost:8585 or http://localhost:8586)
        jwt_token (str): JWT token for authentication
        service_name (str): Name of the MinIO storage service in OpenMetadata
        output_file (str): Path to save the JSON output
    """
    try:
        if not jwt_token:
            raise ValueError("JWT token is empty or not provided")

        headers = {"Authorization": f"Bearer {jwt_token}", "Content-Type": "application/json"}
        
        # Test server connectivity
        try:
            test_response = requests.get(f"{host}/api/v1/system/version", headers=headers, timeout=5)
            test_response.raise_for_status()
            print(f"[OpenMetadata] Server is running: {test_response.json().get('version')}")
        except requests.RequestException as e:
            print(f"[OpenMetadata] Failed to connect to {host}: {str(e)}")
            return []

        # Verify storage service exists
        services = get_storage_services(host, jwt_token)
        if not any(s["name"] == service_name for s in services):
            print(f"[OpenMetadata] Warning: Service {service_name} not found. Listing all tables.")
            service_name = None  # Fallback to list all tables

        # List tables filtered by MinIO storage service (or all tables if service_name is None)
        tables = []
        after = None
        base_url = f"{host}/api/v1/tables"
        params = {"limit": 50}
        if service_name:
            params["service"] = service_name
        
        while True:
            if after:
                params["after"] = after
            
            try:
                response = requests.get(base_url, headers=headers, params=params, timeout=10)
                response.raise_for_status()
                data = response.json()
                tables.extend(data.get("data", []))
                after = data.get("paging", {}).get("after")
                if not after:
                    break
            except requests.HTTPError as e:
                print(f"[OpenMetadata] HTTP error listing tables: {str(e)} (Status: {e.response.status_code})")
                print(f"[OpenMetadata] Response: {e.response.text}")
                return []
            except requests.RequestException as e:
                print(f"[OpenMetadata] Error listing tables: {str(e)}")
                return []
        
        print(f"[OpenMetadata] Found {len(tables)} tables" + (f" in service {service_name}" if service_name else ""))
        
        # Fetch detailed metadata for each table
        detailed_tables = []
        for table in tables:
            fqn = table.get("fullyQualifiedName")
            if not fqn:
                print(f"[OpenMetadata] Skipping table with no FQN: {table}")
                continue
            
            # Get table details
            detail_url = f"{base_url}/name/{fqn}"
            try:
                response = requests.get(detail_url, headers=headers, timeout=10)
                response.raise_for_status()
                table_details = response.json()
                
                # Extract relevant details
                table_info = {
                    "fullyQualifiedName": table_details.get("fullyQualifiedName", ""),
                    "name": table_details.get("name", ""),
                    "description": table_details.get("description", ""),
                    "service": table_details.get("service", {}).get("name", ""),
                    "dataSource": table_details.get("dataSource", {}).get("fullyQualifiedName", ""),
                    "columns": [
                        {
                            "name": col.get("name", ""),
                            "dataType": col.get("dataType", ""),
                            "description": col.get("description", ""),
                            "tags": [tag.get("tagFQN", "") for tag in col.get("tags", [])]
                        }
                        for col in table_details.get("columns", [])
                    ]
                }
                
                detailed_tables.append(table_info)
                print(f"[OpenMetadata] Retrieved details for table {fqn}:")
                print(f"  Description: {table_info['description']}")
                print(f"  Data Source: {table_info['dataSource']}")
                print(f"  Columns: {json.dumps(table_info['columns'], indent=2)}")
            
            except requests.HTTPError as e:
                print(f"[OpenMetadata] HTTP error retrieving details for {fqn}: {str(e)} (Status: {e.response.status_code})")
                print(f"[OpenMetadata] Response: {e.response.text}")
                continue
            except requests.RequestException as e:
                print(f"[OpenMetadata] Error retrieving details for {fqn}: {str(e)}")
                continue
        
        # Save to JSON file
        try:
            with open(output_file, 'w') as f:
                json.dump(detailed_tables, f, indent=2)
            print(f"[OpenMetadata] Saved table metadata to {output_file}")
        except Exception as e:
            print(f"[OpenMetadata] Failed to save JSON to {output_file}: {str(e)}")
        
        return detailed_tables
    
    except Exception as e:
        print(f"[OpenMetadata] Error retrieving MinIO metadata: {str(e)}")
        return []

if __name__ == "__main__":
    # Configuration
    host = "http://127.0.0.1:8585"  # or OPENMETADATA_MCP_HOST
    jwt_token = os.getenv("OPENMETADATA_JWT_TOKEN")
    service_name = os.getenv("OPENMETADATA_MINIO_SERVICE", "customer_data")
    
    if not jwt_token:
        print("[OpenMetadata] Error: OPENMETADATA_JWT_TOKEN not found in environment variables")
    else:
        get_minio_metadata(host, jwt_token, service_name)