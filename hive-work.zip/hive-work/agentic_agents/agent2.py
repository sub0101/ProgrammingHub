# agent.py

from dotenv import load_dotenv
load_dotenv()

import os
import json
from datetime import datetime, timezone
import boto3
from botocore.client import Config
import pyarrow.parquet as pq
from typing import TypedDict, Optional, List, Dict, Any

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableLambda

# ---- CONFIG ----
MINIO_ENDPOINT = "localhost:9000"
MINIO_ACCESS_KEY = "mynewaccesskey"
MINIO_SECRET_KEY = "mynewsecretkey"
MINIO_BUCKET = "mybucket"
DELTA_PREFIX = ""

SCHEMA_CACHE = "schema_cache.json"
CHANGE_LOG = "schema_change_log.json"
LATEST_PARQUET = "latest_schema.parquet"

# ---- LLM Setup using Gemini ----
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    google_api_key=os.getenv("GOOGLE_API_KEY"),
    temperature=0,
)

# ---- MinIO Utilities ----
def get_minio_client():
    return boto3.client(
        's3',
        endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        config=Config(signature_version='s3v4'),
        region_name='us-east-1'
    )

def list_delta_files_with_times(prefix):
    client = get_minio_client()
    response = client.list_objects_v2(Bucket=MINIO_BUCKET, Prefix=prefix)
    files = [
        (obj['Key'], obj['LastModified'])
        for obj in response.get('Contents', []) if obj['Key'].endswith('.parquet')
    ]
    return sorted(files, key=lambda x: x[1])

def download_file(key, local_path):
    client = get_minio_client()
    client.download_file(MINIO_BUCKET, key, local_path)

# ---- Schema Utilities ----
def extract_schema_from_parquet(path):
    table = pq.read_table(path)
    schema = table.schema
    return {"fields": [{"name": f.name, "type": str(f.type)} for f in schema]}

def compare_schemas(old_schema, new_schema):
    old_fields = set((f['name'], f['type']) for f in old_schema.get('fields', []))
    new_fields = set((f['name'], f['type']) for f in new_schema.get('fields', []))
    added = new_fields - old_fields
    removed = old_fields - new_fields
    changes = {}
    if added:
        changes['added'] = [dict(zip(['name', 'type'], x)) for x in added]
    if removed:
        changes['removed'] = [dict(zip(['name', 'type'], x)) for x in removed]
    return changes

# ---- JSON Utilities ----
def load_json(path, default):
    if os.path.exists(path):
        with open(path, 'r') as f:
            return json.load(f)
    return default

def save_json(path, data):
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

# ---- Discovery Agent ----
def discovery_agent(new_schema, file, changes):
    print(f"[Discovery] Triggered for file: {file}")
    print(f"[Discovery] New schema: {json.dumps(new_schema, indent=2)}")
    print(f"[Discovery] Changes: {json.dumps(changes, indent=2)}")

    if changes.get("added"):
        prompt = ChatPromptTemplate.from_template("""
You are a data catalog assistant. Given a list of columns with name and type, return JSON with suggested tags and a brief description for each column.

Example output:
[
  {{ "name": "user_id", "tag": "identifier", "description": "Unique ID of the user." }},
  {{ "name": "email", "tag": "PII", "description": "User's email address." }}
]

Input columns:
{fields}
""")
        fields_json = json.dumps(changes["added"], indent=2)
        input_text = prompt.format(fields=fields_json)

        print(f"[Prompt] Sending to LLM:\n{input_text}")
        response = llm.invoke(input_text)
        print(f"[LLM] Tag Suggestions:\n{response.content}")

    print(f"[Discovery] (Simulated) Would update OpenMetadata for {file}.")
    return {"status": "Discovery complete", "file": file}

# ---- Supervisor Agent ----
def supervisor_agent():
    print("[Supervisor] Checking for schema changes...")
    old_schema = load_json(SCHEMA_CACHE, {"fields": []})
    files_with_times = list_delta_files_with_times(DELTA_PREFIX)
    if not files_with_times:
        return {"new_schema": None, "file": None, "changes": None}

    files = [f[0] for f in files_with_times]
    logs = load_json(CHANGE_LOG, [])
    processed_files = set(entry["file"] for entry in logs)

    for file in files:
        if file in processed_files:
            continue
        download_file(file, LATEST_PARQUET)
        new_schema = extract_schema_from_parquet(LATEST_PARQUET)
        changes = compare_schemas(old_schema, new_schema)

        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "file": file,
            "changes": changes
        }
        logs.append(log_entry)
        save_json(CHANGE_LOG, logs)
        save_json(SCHEMA_CACHE, new_schema)

        if changes:
            print(f"[Supervisor] Detected changes in {file}")
            return {"new_schema": new_schema, "file": file, "changes": changes}
        else:
            print(f"[Supervisor] No changes in {file}")
            old_schema = new_schema

    return {"new_schema": None, "file": None, "changes": None}

# ---- LangGraph State Definition ----
class SchemaState(TypedDict):
    new_schema: Optional[Dict[str, Any]]
    file: Optional[str]
    changes: Optional[Dict[str, List[Dict[str, str]]]]

# ---- LangGraph Nodes ----
def supervisor_node(state: SchemaState) -> SchemaState:
    return supervisor_agent()

def discovery_node(state: SchemaState) -> Dict[str, Any]:
    if state['new_schema']:
        return discovery_agent(state['new_schema'], state['file'], state['changes'])
    return {"status": "No change detected."}

# ---- LangGraph Assembly ----
workflow = StateGraph(SchemaState)

workflow.add_node("Supervisor", RunnableLambda(supervisor_node))
workflow.add_node("Discovery", RunnableLambda(discovery_node))

workflow.set_entry_point("Supervisor")

workflow.add_conditional_edges(
    "Supervisor",
    lambda state: "Discovery" if state.get("changes") else END
)

workflow.add_edge("Discovery", END)

graph = workflow.compile()

# ---- Run the Graph ----
if __name__ == "__main__":
    result = graph.invoke({})
    print("\n[FINAL RESULT]", result)
