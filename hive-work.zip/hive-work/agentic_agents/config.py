import os

MINIO_ENDPOINT = "localhost:9000"
MINIO_ACCESS_KEY = "mynewaccesskey"
MINIO_SECRET_KEY = "mynewsecretkey"
MINIO_BUCKET = "mybucket"
DELTA_PREFIX = ""

SCHEMA_CACHE = "schema_cache.json"
CHANGE_LOG = "schema_change_log.json"
LATEST_PARQUET = "latest_schema.parquet"
