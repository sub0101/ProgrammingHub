from langchain_core.tools import tool
import json

@tool
def log_added_columns(columns: list) -> str:
    """Logs added columns and simulates metadata tagging."""
    for col in columns:
        print(f"[MetadataTool] Tagging column: {col['name']} ({col['type']})")
    return json.dumps({"status": "Logged", "columns": columns}, indent=2)

@tool
def log_removed_columns(columns: list) -> str:
    """Logs removed columns."""
    for col in columns:
        print(f"[MetadataTool] Column removed: {col['name']} ({col['type']})")
    return json.dumps({"status": "RemovedLogged", "columns": columns}, indent=2)
