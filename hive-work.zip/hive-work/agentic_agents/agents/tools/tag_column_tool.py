from langchain.prompts import ChatPromptTemplate
import json

def tag_columns_tool(fields, llm):
    prompt = ChatPromptTemplate.from_template("""
You are a data catalog assistant. Given a list of columns with name and type, return JSON with suggested tags and a brief description for each column.

Example output:
[
  {{ "name": "user_id", "tag": "identifier", "description": "Unique ID of the user." }},
  {{ "name": "email", "tag": "PII", "description": "User's email address." }}
]

Input columns:
{fields}
""")

    fields_json = json.dumps(fields, indent=2)
    input_text = prompt.format(fields=fields_json)
    print(f"[Tool] Prompt Sent:\n{input_text}")

    response = llm.invoke(input_text)
    return response.content
