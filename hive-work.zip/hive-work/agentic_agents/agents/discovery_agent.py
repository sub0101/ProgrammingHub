import json
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
from agents.tools.tag_column_tool import tag_columns_tool
import os

llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    google_api_key=os.getenv("GOOGLE_API_KEY"),
    temperature=0
)

def discovery_agent(new_schema, file, changes):
    print(f"[Discovery] Triggered for file: {file}")
    print(f"[Discovery] New schema: {json.dumps(new_schema, indent=2)}")
    print(f"[Discovery] Changes: {json.dumps(changes, indent=2)}")

    if changes.get("added"):
        result = tag_columns_tool(changes["added"], llm)
        print(f"[Discovery] Result:\n{result}")
    else:
        print("[Discovery] No added columns to process.")

    return {"status": "Discovery complete", "file": file}

