import os
import sys
import json
from datetime import datetime, timezone
import boto3
from botocore.client import Config
import pyarrow.parquet as pq

# ---- CONFIG ----
MINIO_ENDPOINT = "localhost:9000"
MINIO_ACCESS_KEY = "mynewaccesskey"
MINIO_SECRET_KEY = "mynewsecretkey"
MINIO_BUCKET = "mybucket"
DELTA_PREFIX = ""  # e.g., "my-delta-table/"

SCHEMA_CACHE = "schema_cache.json"
CHANGE_LOG = "schema_change_log.json"
LATEST_PARQUET = "latest_schema.parquet"

# ---- MinIO Utilities ----
def get_minio_client():
    print(f"Connecting to MinIO at {MINIO_ENDPOINT} as {MINIO_ACCESS_KEY}...")
    client = boto3.client(
        's3',
        endpoint_url=f"http://{MINIO_ENDPOINT}",
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        config=Config(signature_version='s3v4'),
        region_name='us-east-1'
    )
    print("MinIO client created.")
    return client

def list_delta_files_with_times(prefix):
    print(f"Listing Delta/Parquet files in bucket '{MINIO_BUCKET}' with prefix '{prefix}'...")
    client = get_minio_client()
    response = client.list_objects_v2(Bucket=MINIO_BUCKET, Prefix=prefix)
    files = [
        (obj['Key'], obj['LastModified'])
        for obj in response.get('Contents', []) if obj['Key'].endswith('.parquet')
    ]
    files_sorted = sorted(files, key=lambda x: x[1])
    print(f"Found {len(files_sorted)} files (sorted by last modified): {[f[0] for f in files_sorted]}")
    return files_sorted

def download_file(key, local_path):
    print(f"Downloading file '{key}' from MinIO to '{local_path}'...")
    client = get_minio_client()
    client.download_file(MINIO_BUCKET, key, local_path)
    print(f"Downloaded '{key}' to '{local_path}'.")

# ---- Schema Utilities ----
def extract_schema_from_parquet(path):
    print(f"Extracting schema from Parquet file '{path}'...")
    table = pq.read_table(path)
    schema = table.schema
    schema_dict = {"fields": [{"name": f.name, "type": str(f.type)} for f in schema]}
    print(f"Extracted schema: {json.dumps(schema_dict, indent=2)}")
    return schema_dict

def compare_schemas(old_schema, new_schema):
    print("Comparing old schema to new schema...")
    old_fields = set((f['name'], f['type']) for f in old_schema.get('fields', []))
    new_fields = set((f['name'], f['type']) for f in new_schema.get('fields', []))
    added = new_fields - old_fields
    removed = old_fields - new_fields
    changes = {}
    if added:
        changes['added'] = [dict(zip(['name', 'type'], x)) for x in added]
    if removed:
        changes['removed'] = [dict(zip(['name', 'type'], x)) for x in removed]
    print(f"Schema changes: {json.dumps(changes, indent=2)}")
    return changes

# ---- Main Logic ----
def load_json(path, default):
    if os.path.exists(path):
        print(f"Loading JSON from '{path}'...")
        with open(path, 'r') as f:
            data = json.load(f)
        print(f"Loaded data: {json.dumps(data, indent=2)}")
        return data
    print(f"File '{path}' not found. Using default: {json.dumps(default, indent=2)}")
    return default

def save_json(path, data):
    print(f"Saving JSON to '{path}'...")
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)
    print(f"Saved data: {json.dumps(data, indent=2)}")

def main():
    print("\n=== METADATA MONITOR STARTED ===")
    # 1. Load previous schema
    old_schema = load_json(SCHEMA_CACHE, {"fields": []})

    # 2. List files in MinIO (by last modified time)
    files_with_times = list_delta_files_with_times(DELTA_PREFIX)
    if not files_with_times:
        print("No Delta/Parquet files found in MinIO.")
        return
    files = [f[0] for f in files_with_times]
    print(f"Processing all files (by last modified): {files}")

    # 3. Load already processed files from the log
    logs = load_json(CHANGE_LOG, [])
    processed_files = set(entry["file"] for entry in logs)

    # 4. Process only new files
    for file in files:
        if file in processed_files:
            print(f"Skipping already processed file: {file}")
            continue
        print(f"\n--- Processing file: {file} ---")
        download_file(file, LATEST_PARQUET)
        new_schema = extract_schema_from_parquet(LATEST_PARQUET)
        print("\n=== PREVIOUS SCHEMA ===")
        print(json.dumps(old_schema, indent=2))
        print("\n=== CURRENT SCHEMA ===")
        print(json.dumps(new_schema, indent=2))
        changes = compare_schemas(old_schema, new_schema)
        print("\n=== SCHEMA CHANGES ===")
        if not changes:
            print("No schema changes detected.")
        else:
            print(json.dumps(changes, indent=2))
        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "file": file,
            "changes": changes
        }
        logs.append(log_entry)
        save_json(CHANGE_LOG, logs)
        save_json(SCHEMA_CACHE, new_schema)
        old_schema = new_schema  # update for next file
    print("\n=== METADATA MONITOR FINISHED ===\n")

if __name__ == "__main__":
    main() 