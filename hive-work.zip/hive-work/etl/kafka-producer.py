from confluent_kafka import Producer
import json
import random
import time
from datetime import datetime

# Kafka Config
KAFKA_BROKER = 'localhost:9092'  # Kafka broker address
TOPIC_NAME = 'userData'              # Kafka topic name

# Create Kafka producer instance
producer = Producer({
    'bootstrap.servers': KAFKA_BROKER
})

# Function to generate random user data with updated schema (including `user_id`)
def generate_user_data():
    users = ["Alice", "Bob", "Charlie", "David", "Eve"]
    user_types = ["guest", "registered"]
    cities = ["New York", "Los Angeles", "Chicago", "Houston", "Phoenix"]
    typedevices = ["mobile", "desktop", "tablet"]  # New device types

    user_id = random.randint(1000, 9999)

    user_data = {
        'user': random.choice(users),
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'action': random.choice(['login', 'logout', 'purchase', 'view']),
        'user_type': random.choice(user_types),
        'location': random.choice(cities),
        'user_id': user_id,
        'typedevice': random.choice(typedevices)  # <-- New field added here
    }
    return user_data

# Callback function to handle delivery report
def on_delivery(err, msg):
    if err:
        print(f'Message delivery failed: {err}')
    else:
        print(f'Message delivered to {msg.topic()} [{msg.partition()}]')

# Main loop: produce data every 1 second
try:
    while True:
        user_data = generate_user_data()
        print(f"Producing: {user_data}")
        
        producer.produce(
            TOPIC_NAME,
            value=json.dumps(user_data),
            callback=on_delivery
        )

        # Trigger delivery report callbacks
        producer.poll(0)

        time.sleep(1)

except KeyboardInterrupt:
    print("Stopping producer...")

finally:
    # Ensure all messages are delivered before exit
    producer.flush()
