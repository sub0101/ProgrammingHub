# from pyspark.sql import SparkSession

# spark = SparkSession.builder \
#     .appName("Read Delta from Hive") \
#     .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
#     .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
#     .config("spark.hadoop.fs.s3a.access.key", "mynewaccesskey") \
#     .config("spark.hadoop.fs.s3a.secret.key", "mynewsecretkey") \
#     .config("spark.hadoop.fs.s3a.endpoint", "http://10.0.0.100:9000") \
#     .config("spark.hadoop.fs.s3a.path.style.access", "true") \
#     .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
#     .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false") \
#     .config("spark.jars.packages", ",".join([
#         "io.delta:delta-spark_2.12:3.1.0",
#         "org.apache.hadoop:hadoop-aws:3.3.4",
#         "com.amazonaws:aws-java-sdk-bundle:1.12.262"
#     ])) \
#     .enableHiveSupport() \
#     .getOrCreate()

# # Read from Hive
# df = spark.table("lakehouse.user_data")

# df.show()


from pyspark.sql import SparkSession

# Constants
minio_bucket = "mybucket"
minio_path = "warehouse/lakehouse.db/user_data"
hive_db = "lakehouse"
hive_table = "user_data"
table_full_name = f"{hive_db}.{hive_table}"
table_path = f"s3a://{minio_bucket}/{minio_path}"

# Spark Session
spark = SparkSession.builder \
    .appName("Read Delta from Hive") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .config("spark.hadoop.fs.s3a.access.key", "mynewaccesskey") \
    .config("spark.hadoop.fs.s3a.secret.key", "mynewsecretkey") \
    .config("spark.hadoop.fs.s3a.endpoint", "http://127.0.0.1:9000") \
    .config("spark.hadoop.fs.s3a.path.style.access", "true") \
    .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
    .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false") \
    .config("spark.sql.warehouse.dir", f"s3a://{minio_bucket}/warehouse/") \
    .config("hive.metastore.uris", "thrift://localhost:9083") \
    .config("spark.sql.catalogImplementation", "hive") \
    .config("spark.jars.packages", ",".join([
        "io.delta:delta-spark_2.12:3.1.0",
        "org.apache.hadoop:hadoop-aws:3.3.4",
        "com.amazonaws:aws-java-sdk-bundle:1.12.262"
    ])) \
    .enableHiveSupport() \
    .getOrCreate()

spark.sql("DESCRIBE lakehouse.user_data").show(truncate=False)

spark.sql("SHOW DATABASES").show()
spark.sql("SHOW TABLES IN lakehouse").show()
# Read from Hive
df = spark.table(table_full_name)
df.show(50)

# Stop Spark session
spark.stop()