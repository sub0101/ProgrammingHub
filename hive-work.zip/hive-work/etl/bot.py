# from minio import Minio
# from minio.error import S3Error  # Handle S3 errors (common for MinIO)

# # Initialize MinIO client
# client = Minio(
#     "127.0.0.1:9000",  # MinIO endpoint (localhost in this case)
#     access_key="mynewaccesskey",  # Your MinIO access key
#     secret_key="mynewsecretkey",  # Your MinIO secret key
#     secure=False  # Set to True if using HTTPS
# )

# # Bucket name where the file will be uploaded
# bucket_name = "test"

# # File to be uploaded
# file_path = "file.txt"
# object_name = "file.txt"  # Name of the file on MinIO

# # Check if the bucket exists, if not, create it
# try:
#     if not client.bucket_exists(bucket_name):
#         print(f"Bucket '{bucket_name}' does not exist. Creating it...")
#         client.make_bucket(bucket_name)
# except S3Error as err:  # Handle S3-related errors
#     print(f"S3Error: {err}")

# # Upload the file to the bucket
# try:
#     client.fput_object(bucket_name, object_name, file_path)
#     print(f"File '{object_name}' uploaded successfully to bucket '{bucket_name}'")
# except S3Error as err:  # Handle S3-related errors
#     print(f"S3Error: {err}")
# except Exception as e:
#     # Handle general exceptions
#     print(f"An error occurred: {e}")

import boto3
s3 = boto3.client('s3', endpoint_url='http://172.16.200.34:31713',
                  aws_access_key_id='yXdkVN7a1fJ0C18AbnRP',
                  aws_secret_access_key='fkYDTqHrgYogctfQcQuDOGNRqb5jKbqisGNOsark')
print(s3.list_objects_v2(Bucket='airbyte-test', Prefix='output/'))
# or
print(s3.list_objects_v2(Bucket='airbyte-test', Prefix='new-logs/logs.raw.input'))