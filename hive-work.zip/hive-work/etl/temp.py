from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StringType, IntegerType

# --- Constants ---
minio_bucket = "mybucket"
hive_db = "lakehouse"
hive_table = "user_data"

# --- Spark Session ---
spark = SparkSession.builder \
    .appName("WriteToHiveOnMinIO") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
    .config("spark.hadoop.fs.s3a.access.key", "mynewaccesskey") \
    .config("spark.hadoop.fs.s3a.secret.key", "mynewsecretkey") \
    .config("spark.hadoop.fs.s3a.endpoint", "http://localhost:9000") \
    .config("spark.hadoop.fs.s3a.path.style.access", "true") \
    .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false") \
    .config("spark.sql.warehouse.dir", f"s3a://{minio_bucket}/warehouse/") \
    .config("spark.jars.packages", ",".join([
        "io.delta:delta-spark_2.12:3.1.0",
        "org.apache.hadoop:hadoop-aws:3.3.4",
        "com.amazonaws:aws-java-sdk-bundle:1.12.262"
    ])) \
    .enableHiveSupport() \
    .getOrCreate()


bucket_path = "s3a://mybucket/lakehouse/user_data"
hive_db = "lakehouse"
hive_table = "user_data"
full_table = f"{hive_db}.{hive_table}"

spark.sql(f"DROP TABLE IF EXISTS {full_table}")

# ----------------------------------------
# 4. Sample DataFrame (replace with real data)
# ----------------------------------------
data = [("1", "Alice", 25), ("2", "Bob", 30), ("3", "Charlie", 22)]
df = spark.createDataFrame(data, ["id", "name", "age"])

# ----------------------------------------
# 5. Write DataFrame as Delta to MinIO path
# ----------------------------------------
df.write.format("delta").mode("overwrite").save(bucket_path)

# ----------------------------------------
# 6. Register it in Hive metastore
# ----------------------------------------
spark.sql(f"""
    CREATE TABLE {full_table}
    USING DELTA
    LOCATION '{bucket_path}'
""")

print(f"✅ Successfully wrote Delta table to Hive as: {full_table}")


