# import json
# import os
# from pyspark.sql import SparkSession
# from pyspark.sql.functions import col, from_json
# from pyspark.sql.types import StructType, StringType, IntegerType

# # Kafka topic and offset tracking file
# offset_file = "./kafka_offsets.json"
# topic = "userData"

# # MinIO Delta path
# minio_bucket = "mybucket"
# minio_path = "delta2/user_data"  # location for delta table data

# # Hive database and table
# hive_db = "lakehouse"
# hive_table = "user_data"

# def load_offsets():
#     if os.path.exists(offset_file):
#         with open(offset_file, "r") as f:
#             return json.load(f)
#     return {}

# def save_offsets(offsets):
#     with open(offset_file, "w") as f:
#         json.dump(offsets, f, indent=2)

# def get_spark_session():
#     return SparkSession.builder \
#         .appName("KafkaToMinIOHive") \
#         .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
#         .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
#         .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
#         .config("spark.hadoop.fs.s3a.access.key", "mynewaccesskey") \
#         .config("spark.hadoop.fs.s3a.secret.key", "mynewsecretkey") \
#         .config("spark.hadoop.fs.s3a.endpoint", "http://127.0.0.1:9000") \
#         .config("spark.hadoop.fs.s3a.path.style.access", "true") \
#         .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false") \
#         .config("spark.sql.warehouse.dir", f"s3a://{minio_bucket}/warehouse/") \
#         .config("spark.jars.packages", ",".join([
#             # "org.apache.hadoop:hadoop-aws:3.3.4",
#             "org.apache.hadoop:hadoop-aws:3.3.4",
#             "com.amazonaws:aws-java-sdk-bundle:1.12.262",
#             # "com.amazonaws:aws-java-sdk-bundle:1.12.367",
#             "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.5",
#             "io.delta:delta-spark_2.12:3.1.0"
#         ])) \
#         .enableHiveSupport() \
#         .getOrCreate()

# def read_from_kafka(spark, topic, startingOffsets="earliest"):
#     return spark.read.format("kafka") \
#         .option("kafka.bootstrap.servers", "localhost:9092") \
#         .option("subscribe", topic) \
#         .option("startingOffsets", startingOffsets) \
#         .load()

# def save_kafka_offsets(kafka_df, last_offsets, topic):
#     latest_offsets = {}
#     for row in kafka_df.select("partition", "offset").distinct().collect():
#         partition, offset = row["partition"], row["offset"]
#         latest_offsets[str(partition)] = max(latest_offsets.get(str(partition), 0), offset + 1)
#     last_offsets[topic] = latest_offsets
#     save_offsets(last_offsets)

# def process_and_show_data(kafka_df):
#     schema = StructType() \
#         .add("user", StringType()) \
#         .add("action", StringType()) \
#         .add("user_type", StringType()) \
#         .add("location", StringType()) \
#         .add("timestamp", StringType()) \
#         .add("user_id", IntegerType())

#     parsed_df = kafka_df.selectExpr("CAST(value AS STRING) as json_str") \
#                         .select(from_json(col("json_str"), schema).alias("data")) \
#                         .select("data.*")

#     parsed_df.show(truncate=False)
#     return parsed_df

# def write_to_minio_and_register_in_hive(df, spark):
#     # Create Hive DB if not exists
#     spark.sql(f"CREATE DATABASE IF NOT EXISTS {hive_db}")

#     # Save as managed Hive table backed by Delta Lake
#     df.write.format("delta") \
#         .option("mergeSchema", "true") \
#         .mode("append") \
#         .saveAsTable(f"{hive_db}.{hive_table}")

#     print(f"✅ Written to Hive table: {hive_db}.{hive_table}")

# def main():
#     last_offsets = load_offsets()
#     topic_offsets = last_offsets.get(topic, {})

#     if topic_offsets:
#         startingOffsets = json.dumps({topic: {str(k): v for k, v in topic_offsets.items()}})
#     else:
#         print("No previous offsets found, defaulting to earliest.")
#         startingOffsets = "earliest"

#     spark = get_spark_session()
#     kafka_df = read_from_kafka(spark, topic, startingOffsets)

#     if kafka_df.count() == 0:
#         print("No new Kafka messages. Exiting.")
#         spark.stop()
#         return

#     processed_df = process_and_show_data(kafka_df)
#     write_to_minio_and_register_in_hive(processed_df, spark)
#     save_kafka_offsets(kafka_df, last_offsets, topic)
#     spark.stop()

# if __name__ == "__main__":
#     main()

import json
import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, to_timestamp
from pyspark.sql.types import StructType, StringType, IntegerType
from delta.tables import DeltaTable

# Kafka topic and offset tracking file
offset_file = "./kafka_offsets.json"
topic = "userData"

# MinIO Delta path
minio_bucket = "mybucket"
minio_path = "warehouse/lakehouse.db/user_data"  # location for delta table data

# Hive database and table
hive_db = "lakehouse"
hive_table = "user_data"

def load_offsets():
    if os.path.exists(offset_file):
        with open(offset_file, "r") as f:
            return json.load(f)
    return {}

def save_offsets(offsets):
    with open(offset_file, "w") as f:
        json.dump(offsets, f, indent=2)

def get_spark_session():
    return SparkSession.builder \
        .appName("KafkaToMinIOHive") \
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
        .config("spark.hadoop.fs.s3a.access.key", "mynewaccesskey") \
        .config("spark.hadoop.fs.s3a.secret.key", "mynewsecretkey") \
        .config("spark.hadoop.fs.s3a.endpoint", "http://10.0.0.100:9000") \
        .config("spark.hadoop.fs.s3a.path.style.access", "true") \
        .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false") \
        .config("spark.sql.warehouse.dir", f"s3a://{minio_bucket}/warehouse/") \
        .config("hive.metastore.uris", "thrift://localhost:9083") \
        .config("spark.sql.catalogImplementation", "hive") \
        .config("spark.jars.packages", ",".join([
            "org.apache.hadoop:hadoop-aws:3.3.4",
            "com.amazonaws:aws-java-sdk-bundle:1.12.262",
            "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.5",
            "io.delta:delta-spark_2.12:3.1.0"
        ])) \
        .enableHiveSupport() \
        .getOrCreate()

def read_from_kafka(spark, topic, startingOffsets="earliest"):
    return spark.read.format("kafka") \
        .option("kafka.bootstrap.servers", "localhost:9092") \
        .option("subscribe", topic) \
        .option("startingOffsets", startingOffsets) \
        .load()

def save_kafka_offsets(kafka_df, last_offsets, topic):
    latest_offsets = {}
    for row in kafka_df.select("partition", "offset").distinct().collect():
        partition, offset = row["partition"], row["offset"]
        latest_offsets[str(partition)] = max(latest_offsets.get(str(partition), 0), offset + 1)
    last_offsets[topic] = latest_offsets
    save_offsets(last_offsets)

def process_and_show_data(kafka_df):
    schema = StructType() \
        .add("user", StringType()) \
        .add("action", StringType()) \
        .add("user_type", StringType()) \
        .add("location", StringType()) \
        .add("timestamp", StringType()) \
        .add("user_id", IntegerType()) \
        .add("typedevices", StringType()) 

    parsed_df = kafka_df.selectExpr("CAST(value AS STRING) as json_str") \
                        .select(from_json(col("json_str"), schema).alias("data")) \
                        .select("data.*") \
                        .withColumn("timestamp", to_timestamp(col("timestamp"), "yyyy-MM-dd HH:mm:ss"))

    parsed_df.show(truncate=False)
    return parsed_df


def write_to_minio_and_register_in_hive(df, spark):
    table_full_name = f"{hive_db}.{hive_table}"
    table_path = f"s3a://{minio_bucket}/{minio_path}"

    # Create database if it doesn't exist
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {hive_db}")

    # Check if Delta table exists in MinIO
    table_exists = DeltaTable.isDeltaTable(spark, table_path)

    if not table_exists:
        # Drop any stale metadata and create a new table
        spark.sql(f"DROP TABLE IF EXISTS {table_full_name}")
        print(f"📝 Creating new Delta table at {table_path}...")
        df.write.format("delta") \
            .option("mergeSchema", "true") \
            .mode("overwrite") \
            .save(table_path)
        # Register in Hive metastore
        print(f"📝 Registering table {table_full_name} in Hive metastore...")
        spark.sql(f"""
            CREATE TABLE {table_full_name}
            USING DELTA
            LOCATION '{table_path}'
        """)
    else:
        # Append to existing table
        print(f"📝 Appending to Delta table at {table_path}...")
        df.write.format("delta") \
            .option("mergeSchema", "true") \
            .mode("append") \
            .save(table_path)

    # Optimize the table
    print(f"📝 Optimizing Delta table {table_full_name}...")
    spark.sql(f"OPTIMIZE {table_full_name}")

    print(f"✅ Successfully wrote and registered Delta table: {table_full_name} at {table_path}")

def main():
    last_offsets = load_offsets()
    topic_offsets = last_offsets.get(topic, {})

    if topic_offsets:
        startingOffsets = json.dumps({topic: {str(k): v for k, v in topic_offsets.items()}})
    else:
        print("No previous offsets found, defaulting to earliest.")
        startingOffsets = "earliest"

    spark = get_spark_session()
    kafka_df = read_from_kafka(spark, topic, startingOffsets)

    if kafka_df.count() == 0:
        print("No new Kafka messages. Exiting.")
        spark.stop()
        return

    processed_df = process_and_show_data(kafka_df)
    write_to_minio_and_register_in_hive(processed_df, spark)
    save_kafka_offsets(kafka_df, last_offsets, topic)
    spark.stop()

if __name__ == "__main__":
    main()