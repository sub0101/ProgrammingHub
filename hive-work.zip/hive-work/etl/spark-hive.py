from pyspark.sql import SparkSession

def get_spark_session():
    return SparkSession.builder \
        .appName("RegisterHiveLakehouse") \
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
        .config("spark.sql.catalogImplementation", "hive") \
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
        .config("spark.hadoop.fs.s3a.access.key", "mynewaccesskey") \
        .config("spark.hadoop.fs.s3a.secret.key", "mynewsecretkey") \
        .config("spark.hadoop.fs.s3a.endpoint", "http://127.0.0.1:9000") \
        .config("spark.hadoop.fs.s3a.path.style.access", "true") \
        .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false") \
        .config("spark.sql.warehouse.dir", "s3a://mybucket/warehouse/") \
        .config("hive.metastore.uris", "thrift://localhost:9083") \
        .config("spark.jars.packages", ",".join([
            "org.apache.hadoop:hadoop-aws:3.3.4",
            "com.amazonaws:aws-java-sdk-bundle:1.12.262",
            "io.delta:delta-spark_2.12:3.1.0"
        ])) \
        .enableHiveSupport() \
        .getOrCreate()

def main():
    spark = get_spark_session()

    print("\n📂 Creating database if not exists...")
    spark.sql("CREATE DATABASE IF NOT EXISTS lakehouse")

    print("\n📁 Switching to lakehouse and showing tables...")
    spark.sql("USE lakehouse")
    spark.sql("SHOW TABLES").show(truncate=False)

    spark.stop()

if __name__ == "__main__":
    main()
