# === Previous code commented out ===
'''
from typing import TypedDict, Dict, Any
import json
import re
from datetime import datetime, timezone
import os
import requests
from spark_job import run_spark_job
from config import INTEGRATION_LOG, MINIO_DELTA_BUCKET
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Define state
class AgentState(TypedDict):
    new_schema: Dict[str, Any]
    file: str
    changes: Dict[str, Any]
    tags: str
    last_action: str
    decision: str
    human_approved_validation: bool
    human_approved_discovery: bool
    integration_log: list

def load_json(path: str, default: Any) -> Any:
    try:
        if os.path.exists(path):
            with open(path) as f:
                data = json.load(f)
                print(f"[Integration Agent] Loaded JSON from {path}: {data}")
                return data
        print(f"[Integration Agent] No JSON file at {path}, using default: {default}")
        return default
    except Exception as e:
        print(f"[Integration Agent] Failed to load JSON from {path}: {str(e)}")
        return default

def save_json(path: str, data: Any) -> None:
    try:
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"[Integration Agent] Saved JSON to {path}")
    except Exception as e:
        print(f"[Integration Agent] Failed to save JSON to {path}: {str(e)}")

def update_openmetadata_schema(new_schema, tags):
    try:
        headers = {
            "Authorization": f"Bearer {os.getenv('OPENMETADATA_TOKEN')}",
            "Content-Type": "application/json"
        }
        # Get table details
        response = requests.get(
            "http://127.0.0.1:8585/api/v1/tables/name/hive.lakehouse.user_data",
            headers=headers 
        )
        if response.status_code == 401:
            raise Exception("Unauthorized: Invalid OpenMetadata token")
        response.raise_for_status()
        table_data = response.json()

        # Update schema with tags
        payload = {
            "description": "User data table",
            "columns": [
                {
                    "name": field["name"],
                    "dataType": field["type"].upper().replace("TIMESTAMP[NS]", "TIMESTAMP"),
                    "tags": [tag["tag"] for tag in json.loads(tags) if tag["name"] == field["name"]]
                } for field in new_schema["fields"]
            ]
        }
        response = requests.patch(
            f"http://127.0.0.1:8585/api/v1/tables/{table_data['id']}",
            headers=headers,
            json=payload
        )
        response.raise_for_status()
        print(f"[Integration Agent] Successfully updated OpenMetadata: {response.json()}")
        return {"status": "success"}
    except Exception as e:
        print(f"[Integration Agent] OpenMetadata API error: {str(e)}")
        return {"status": "error", "message": str(e)}

def integration_agent(state: AgentState) -> AgentState:
    try:
        # Run Spark job to update Iceberg table
        spark_result = run_spark_job(f"s3a://{MINIO_DELTA_BUCKET}/warehouse/user_data")
        if spark_result["status"] != "success":
            print(f"[Integration Agent] Spark job failed: {spark_result['message']}")
            state["decision"] = "end"
            state["last_action"] = "error"
            state["integration_error"] = spark_result["message"]
            return state

        # Update OpenMetadata
        tags = re.sub(r'^```json\n|\n```$', '', state["tags"]).strip()
        openmetadata_result = update_openmetadata_schema(state["new_schema"], tags)
        if openmetadata_result["status"] != "success":
            print(f"[Integration Agent] OpenMetadata update failed: {openmetadata_result['message']}")
            state["decision"] = "end"
            state["last_action"] = "error"
            state["integration_error"] = openmetadata_result["message"]
            return state

        # Log integration
        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "file": state["file"],
            "changes": state["changes"],
            "tags": json.loads(tags),
            "status": "applied"
        }
        
        logs = load_json(INTEGRATION_LOG, [])
        logs.append(log_entry)
        save_json(INTEGRATION_LOG, logs)
        
        print(f"[Integration Agent] Successfully integrated changes for {state['file']}")
        state["integration_log"] = logs
        state["decision"] = "end"
        state["last_action"] = "integration_done"
        return state
    except Exception as e:
        print(f"[Integration Agent] Error: {str(e)}")
        state["decision"] = "end"
        state["last_action"] = "error"
        state["integration_error"] = str(e)
        return state
'''

# openmetadata_tool_loader.py

import requests
MCP_URL="http://0.0.0.0:8000"
resp = requests.get(f"{MCP_URL}/openapi.json")
openapi = resp.json()
paths = list(openapi.get("paths", {}).keys())
print("Available endpoints:", paths)



# # langchain_mcp_agent.py

# import os
# import requests
# from langchain_google_genai import ChatGoogleGenerativeAI
# from langchain.agents import initialize_agent, AgentType
# from langchain.tools import tool

# # === ENVIRONMENT ===
# MCP_SERVER = os.getenv("MCP_SERVER", "http://localhost:8000")
# OPENMETADATA_TOKEN = os.getenv("OPENMETADATA_TOKEN")

# # === DYNAMIC TOOL GENERATION ===
# def generate_tools_from_openapi(mcp_url: str, token: str):
#     response = requests.get(f"{mcp_url}/openapi.json")
#     openapi = response.json()
#     tools = []

#     for path, methods in openapi.get("paths", {}).items():
#         for method, meta in methods.items():
#             operation_id = meta.get("operationId") or f"{method}_{path.strip('/').replace('/', '_')}"
#             description = meta.get("summary") or f"{method.upper()} {path}"

#             def make_tool(path=path, method=method.upper(), op_id=operation_id):
#                 @tool(name=op_id, description=description)
#                 def dynamic_tool(params: dict):
#                     url = mcp_url + path
#                     headers = {"Authorization": f"Bearer {token}"}
#                     resp = requests.request(method, url, headers=headers, json=params)
#                     try:
#                         return resp.json()
#                     except Exception:
#                         return resp.text
#                 return dynamic_tool

#             tools.append(make_tool())

#     return tools

# # === LLM ===
# llm = ChatGoogleGenerativeAI(
#     model="gemini-1.5-flash",
#     google_api_key=os.getenv("GOOGLE_API_KEY"),
#     temperature=0
# )

# # === TOOLS FROM MCP ===
# tools = generate_tools_from_openapi(MCP_SERVER, OPENMETADATA_TOKEN)

# # === AGENT ===
# agent = initialize_agent(
#     tools=tools,
#     llm=llm,
#     agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
#     verbose=True
# )

# # === EXAMPLE USAGE ===
# if __name__ == "__main__":
#     print("Available tools:")
#     for t in tools:
#         print(f"\u2728 {t.name}: {t.description}")

#     # Run test prompt (optional)
#     result = agent.run("Update the description of the 'email' column in table 'sample_hive.default.users' to 'User email address'")
#     print("\nResult:", result)
