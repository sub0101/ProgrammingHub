# from typing import TypedDict, Dict, Any
# import json
# from pyspark.sql import SparkSession
# from config import MINIO_ICEBERG_BUCKET

# # Define state
# class AgentState(TypedDict):
#     new_schema: Dict[str, Any]
#     file: str
#     changes: Dict[str, Any]
#     tags: str
#     last_action: str
#     decision: str
#     human_approved_validation: bool
#     human_approved_discovery: bool
#     integration_log: list

# def get_spark_session():
#     return SparkSession.builder \
#         .appName("SchemaValidation") \
#         .config("spark.sql.catalog.hive", "org.apache.iceberg.spark.SparkCatalog") \
#         .config("spark.sql.catalog.hive.type", "hive") \
#         .config("spark.sql.catalog.hive.uri", "thrift://localhost:9083") \
#         .config("spark.sql.catalog.hive.warehouse", f"s3a://{MINIO_ICEBERG_BUCKET}/warehouse/") \
#         .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
#         .config("spark.hadoop.fs.s3a.access.key", "mynewaccesskey") \
#         .config("spark.hadoop.fs.s3a.secret.key", "mynewsecretkey") \
#         .config("spark.hadoop.fs.s3a.endpoint", "http://10.0.0.100:9000") \
#         .config("spark.hadoop.fs.s3a.path.style.access", "true") \
#         .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false") \
#         .config("spark.sql.catalogImplementation", "hive") \
#         .config("hive.metastore.uris", "thrift://localhost:9083") \
#         .config("spark.jars.packages", ",".join([
#             "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.5.0",
#             "org.apache.hadoop:hadoop-aws:3.3.4",
#             "com.amazonaws:aws-java-sdk-bundle:1.12.262"
#         ])) \
#         .enableHiveSupport() \
#         .getOrCreate()

# def validation_agent(state: AgentState) -> AgentState:
#     try:
#         spark = get_spark_session()
#         table_name = "hive.lakehouse.user_data"
        
#         # Get Hive metastore schema
#         try:
#             hive_schema_df = spark.sql(f"DESCRIBE TABLE {table_name}")
#             hive_schema = [{"name": row.col_name, "type": row.data_type} for row in hive_schema_df.collect() if not row.col_name.startswith('#')]
#             print(f"[Validation Agent] Hive metastore schema: {hive_schema}")
#         except Exception as e:
#             print(f"[Validation Agent] Table {table_name} not found in Hive metastore: {str(e)}")
#             hive_schema = []
        
#         # Compare new schema with Hive schema
#         new_fields = {(f["name"], f["type"]) for f in state["new_schema"]["fields"]}
#         hive_fields = {(f["name"], f["type"]) for f in hive_schema}
#         duplicates = [(name, t1, t2) for name, t1 in new_fields for hname, t2 in hive_fields if name == hname and t1 != t2]
        
#         if duplicates:
#             print(f"[Validation Agent] Duplicate fields detected with different types: {duplicates}")
#             state["decision"] = "end"
#             state["last_action"] = "validation_failed"
#             state["validation_error"] = f"Duplicate fields: {duplicates}"
#         else:
#             print("[Validation Agent] No duplicate fields detected")
#             state["decision"] = "human_validation"
#             state["last_action"] = "validation_done"
        
#         spark.stop()
#         return state
#     except Exception as e:
#         print(f"[Validation Agent] Error: {str(e)}")
#         state["decision"] = "end"
#         state["last_action"] = "error"
#         state["validation_error"] = str(e)
#         return state


from typing import TypedDict, Dict, Any
import json

# Define state
class AgentState(TypedDict):
    new_schema: Dict[str, Any]
    file: str
    changes: Dict[str, Any]
    tags: str
    last_action: str
    decision: str
    human_approved_validation: bool
    human_approved_discovery: bool
    integration_log: list

def validation_agent(state: AgentState) -> AgentState:
    try:
        # Extract field names from the new schema
        new_fields = [f["name"] for f in state["new_schema"]["fields"]]
        
        # Check for duplicate column names
        seen = set()
        duplicates = [name for name in new_fields if name in seen or seen.add(name)]
        
        if duplicates:
            print(f"[Validation Agent] Duplicate column names detected: {duplicates}")
            state["decision"] = "end"
            state["last_action"] = "validation_failed"
            state["validation_error"] = f"Duplicate columns: {duplicates}"
        else:
            print("[Validation Agent] No duplicate column names detected")
            state["decision"] = "human_validation"
            state["last_action"] = "validation_done"
        
        return state
    except Exception as e:
        print(f"[Validation Agent] Error: {str(e)}")
        state["decision"] = "end"
        state["last_action"] = "error"
        state["validation_error"] = str(e)
        return state