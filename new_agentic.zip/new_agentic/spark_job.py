from pyspark.sql import SparkSession
from config import MINIO_DELTA_BUCKET, MINIO_ICEBERG_BUCKET

def get_spark_session():
    return SparkSession.builder \
        .appName("DeltaToIceberg") \
        .config("spark.sql.defaultCatalog", "hive") \
        .config("spark.sql.catalog.hive", "org.apache.iceberg.spark.SparkCatalog") \
        .config("spark.sql.catalog.hive.type", "hive") \
        .config("spark.sql.catalog.hive.uri", "thrift://localhost:9083") \
        .config("spark.sql.catalog.hive.warehouse", f"s3a://{MINIO_ICEBERG_BUCKET}/warehouse/") \
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem") \
        .config("spark.hadoop.fs.s3a.access.key", "mynewaccesskey") \
        .config("spark.hadoop.fs.s3a.secret.key", "mynewsecretkey") \
        .config("spark.hadoop.fs.s3a.endpoint", "http://10.0.0.100:9000") \
        .config("spark.hadoop.fs.s3a.path.style.access", "true") \
        .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false") \
        .config("spark.sql.catalogImplementation", "hive") \
        .config("hive.metastore.uris", "thrift://localhost:9083") \
        .config("spark.hadoop.hive.metastore.warehouse.dir", f"s3a://{MINIO_ICEBERG_BUCKET}/warehouse/") \
        .config("spark.jars.packages", ",".join([
            "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.5.0",
            "org.apache.hadoop:hadoop-aws:3.3.4",
            "com.amazonaws:aws-java-sdk-bundle:1.12.262",
            "io.delta:delta-spark_2.12:3.2.0"
        ])) \
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
        .enableHiveSupport() \
        .getOrCreate()

def write_to_minio_and_register_in_hive(df, spark, iceberg_catalog="hive", hive_db="lakehouse", hive_table="user_data"):
    try:
        table_full_name = f"{iceberg_catalog}.{hive_db}.{hive_table}"
        print(f"[Spark Job] Processing table: {table_full_name}")

        # Create database with explicit location
        spark.sql(f"CREATE DATABASE IF NOT EXISTS {iceberg_catalog}.{hive_db} LOCATION 's3a://{MINIO_ICEBERG_BUCKET}/warehouse/{hive_db}.db'")

        # Check if table exists
        existing_tables = spark.sql(f"SHOW TABLES IN {iceberg_catalog}.{hive_db}").toPandas()
        table_exists = hive_table in existing_tables["tableName"].values

        if not table_exists:
            print(f"[Spark Job] Creating new Iceberg table {table_full_name}...")
            df.writeTo(table_full_name).using("iceberg").createOrReplace()
        else:
            print(f"[Spark Job] Merging new data into Iceberg table {table_full_name}...")
            # Use MERGE INTO to append only new rows based on user_id
            df.createOrReplaceTempView("temp_view")
            spark.sql(f"""
                MERGE INTO {table_full_name} t
                USING temp_view s
                ON t.user_id = s.user_id
                WHEN NOT MATCHED THEN INSERT *
            """)

        # Verify table location
        location = spark.sql(f"DESCRIBE FORMATTED {table_full_name}") \
            .filter("col_name = 'Location'").collect()[0]["data_type"]
        print(f"[Spark Job] Table location: {location}")

        # Verify schema
        spark.sql(f"DESCRIBE {table_full_name}").show(truncate=False)

        # Verify written data
        written_df = spark.table(table_full_name)
        written_count = written_df.count()
        print(f"[Spark Job] Iceberg table contains {written_count} rows after write")
        written_df.show(truncate=False)

        print(f"[Spark Job] Successfully wrote to Iceberg table: {table_full_name}")
    except Exception as e:
        print(f"[Spark Job] Error writing to table {table_full_name}: {str(e)}")
        raise

def run_spark_job(delta_path):
    try:
        spark = get_spark_session()
        # Read from Delta table
        df = spark.read.format("delta").load(delta_path)
        row_count = df.count()
        print(f"[Spark Job] Read {row_count} rows from Delta table: {delta_path}")
        df.show(truncate=False)

        # Write to Iceberg table
        write_to_minio_and_register_in_hive(df, spark)

        spark.stop()
        return {"status": "success"}
    except Exception as e:
        print(f"[Spark Job] Error: {str(e)}")
        spark.stop()
        return {"status": "error", "message": str(e)}

if __name__ == "__main__":
    delta_path = f"s3a://{MINIO_DELTA_BUCKET}/warehouse/user_data"
    run_spark_job(delta_path)