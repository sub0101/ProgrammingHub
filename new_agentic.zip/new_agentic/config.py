# import os

# # Hive connection settings
# HIVE_HOST = os.getenv("HIVE_HOST", "localhost")
# HIVE_PORT = os.getenv("HIVE_PORT", "10000")
# HIVE_DATABASE = os.getenv("HIVE_DATABASE", "lakehouse")
# HIVE_USER = os.getenv("HIVE_USER", "hive_user")
# HIVE_PASSWORD = os.getenv("HIVE_PASSWORD", "your_password")

# # OpenMetadata settings
# OPENMETADATA_HOST = os.getenv("OPENMETADATA_HOST", "http://127.0.0.1:8585")
# OPENMETADATA_TOKEN = os.getenv("OPENMETADATA_TOKEN", "eyJraWQiOiJHYjM4OWEtOWY3Ni1nZGpzLWE5MmotMDI0MmJrOTQzNTYiLCJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJvcGVuLW1ldGFkYXRhLm9yZyIsInN1YiI6ImFkbWluIiwicm9sZXMiOlsiQWRtaW4iXSwiZW1haWwiOiJhZG1pbkBvcGVuLW1ldGFkYXRhLm9yZyIsImlzQm90IjpmYWxzZSwidG9rZW5UeXBlIjoiUEVSU09OQUxfQUNDRVNTIiwiaWF0IjoxNzUyNTYzMDgwLCJleHAiOjE3NjAzMzkwODB9.zAUR33kW29Kpyrue1-68nH09CaI0wL1qCDN13VbRI2a1sM6DcAZiNyV8jq-C7Vlr4UI_rFmaLf2TNTRK60u2so94HDA_Zf0WmDhEVOkqp3U6K0tKYpK-uUuG9uaYmXgMAQD0ouE04H_CTgI2QqG_7yK3AubbBNkFhB8B6hzhtrBLxzCaCHxPRfytgIny8NO-4kvqrKj6OGP2gZXtcc3zAp7DhvDMGfYn_M1VG7RMpE9sOvmKYfvqF_vSvtDUQE_1k2CIj3OrHx2gsrOW79uu8U24hN9NfruaCb_chV4RtQnBRixDVpmnI77ZIFqkQ9KDLp7flXKIBy3H9IXPg1XI0g")
# OPENMETADATA_SERVICE_NAME = os.getenv("OPENMETADATA_SERVICE_NAME", "customers")  # Hive service in OpenMetadata

# # Log file paths
# SCHEMA_CACHE = "logs/schema_cache.json"
# CHANGE_LOG = "logs/change_log.json"
# INTEGRATION_LOG = "logs/integration_log.json"


import os

MINIO_ENDPOINT = "10.0.0.100:9000"
MINIO_ACCESS_KEY = "mynewaccesskey"
MINIO_SECRET_KEY = "mynewsecretkey"
MINIO_DELTA_BUCKET = "data"
MINIO_ICEBERG_BUCKET = "mybucket"
DELTA_PREFIX = "warehouse/user_data"
SCHEMA_CACHE = "logs/schema_cache.json"
CHANGE_LOG = "logs/change_log.json"
LATEST_PARQUET = "logs/latest_schema.parquet"
INTEGRATION_LOG = "logs/integration_log.json"