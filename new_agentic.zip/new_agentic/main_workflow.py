from typing import TypedDict, Dict, Any
from langgraph.graph import StateGraph, END
from schema_watcher.schema_watcher import get_schema_state
from agents.supervisor_agent import supervisor_agent
from agents.validation_agent import validation_agent
from agents.discovery_agent import discovery_agent
from agents.integration_agent import integration_agent
import json
from dotenv import load_dotenv
import traceback

# Load environment variables
load_dotenv()

# Define state
class AgentState(TypedDict):
    new_schema: Dict[str, Any]
    file: str
    changes: Dict[str, Any]
    tags: str
    last_action: str
    decision: str
    human_approved_validation: bool
    human_approved_discovery: bool
    integration_log: list

def human_validation_review(state: AgentState) -> AgentState:
    try:
        error = state.get("validation_error", "No validation errors")
        print(f"\n[Human Validation Review] Validation results for {state['file']}:\nError: {error}\nSchema: {json.dumps(state['new_schema'], indent=2)}")
        approval = input("Approve validation results? (yes/no): ").lower().strip() == "yes"
        
        state["human_approved_validation"] = approval
        state["decision"] = "discovery" if approval else "end"
        state["last_action"] = "human_validation_reviewed"
        print(f"[Human Validation Review] Approval: {approval}")
        return state
    except Exception as e:
        print(f"[Human Validation Review] Error: {str(e)}")
        state["decision"] = "end"
        state["last_action"] = "error"
        return state

def human_discovery_review(state: AgentState) -> AgentState:
    try:
        print(f"\n[Human Discovery Review] Suggested tags for {state['file']}:\n{state['tags']}")
        approval = input("Approve tags? (yes/no): ").lower().strip() == "yes"
        
        state["human_approved_discovery"] = approval
        state["decision"] = "integration" if approval else "discovery"
        state["last_action"] = "human_discovery_reviewed"
        print(f"[Human Discovery Review] Approval: {approval}")
        return state
    except Exception as e:
        print(f"[Human Discovery Review] Error: {str(e)}")
        state["decision"] = "end"
        state["last_action"] = "error"
        return state

# Define the workflow
workflow = StateGraph(AgentState)

# Add nodes
workflow.add_node("schema_watcher", get_schema_state)
workflow.add_node("supervisor", supervisor_agent)
workflow.add_node("validation", validation_agent)
workflow.add_node("human_validation", human_validation_review)
workflow.add_node("discovery", discovery_agent)
workflow.add_node("human_discovery", human_discovery_review)
workflow.add_node("integration", integration_agent)

# Define edges
workflow.set_entry_point("schema_watcher")
workflow.add_conditional_edges(
    "schema_watcher",
    lambda state: state["decision"],
    {
        "end": END,
        None: "supervisor"
    }
)
workflow.add_conditional_edges(
    "supervisor",
    lambda state: state["decision"],
    {
        "validation": "validation",
        "end": END
    }
)
workflow.add_conditional_edges(
    "validation",
    lambda state: state["decision"],
    {
        "human_validation": "human_validation",
        "end": END
    }
)
workflow.add_conditional_edges(
    "human_validation",
    lambda state: state["decision"],
    {
        "discovery": "discovery",
        "end": END
    }
)
workflow.add_conditional_edges(
    "discovery",
    lambda state: state["decision"],
    {
        "human_discovery": "human_discovery",
        "integration": "integration",
        "end": END
    }
)
workflow.add_conditional_edges(
    "human_discovery",
    lambda state: state["decision"],
    {
        "integration": "integration",
        "discovery": "discovery",
        "end": END
    }
)
workflow.add_edge("integration", END)

# Compile and run
def run_workflow():
    try:
        app = workflow.compile()
        initial_state = {
            "new_schema": {},
            "file": "",
            "changes": {},
            "tags": "",
            "last_action": "",
            "decision": "",
            "human_approved_validation": False,
            "human_approved_discovery": False,
            "integration_log": []
        }
        
        print("[Workflow] Starting schema change detection...")
        result = app.invoke(initial_state)
        # If schema changes detected, force validation
        if result.get("changes", {}).get("added") or result.get("changes", {}).get("removed"):
            print("[Workflow] Schema changes detected, forcing validation")
            result["decision"] = "validation"
            result = app.invoke(result)
        # If no schema changes but files exist, run integration
        elif result["decision"] == "end" and list_delta_files():
            print("[Workflow] No schema changes but files exist, running integration")
            result["decision"] = "integration"
            result["new_schema"] = {"fields": [
                {"name": "user", "type": "string"},
                {"name": "action", "type": "string"},
                {"name": "user_type", "type": "string"},
                {"name": "location", "type": "string"},
                {"name": "timestamp", "type": "timestamp[ns]"},
                {"name": "user_id", "type": "int32"},
                {"name": "typedevices", "type": "string"}
            ]}
            result["tags"] = json.dumps([
                {"name": "user", "tag": "personal_data"},
                {"name": "action", "tag": "event"},
                {"name": "user_type", "tag": "category"},
                {"name": "location", "tag": "geographic"},
                {"name": "timestamp", "tag": "temporal"},
                {"name": "user_id", "tag": "identifier"},
                {"name": "typedevices", "tag": "device_info"}
            ])
            result = app.invoke(result)
        print("[Workflow] Final state:", json.dumps(result, indent=2))
        return result
    except Exception as e:
        print(f"[Workflow] Error: {str(e)}")
        print(f"[Workflow] Stack trace:\n{traceback.format_exc()}")
        return None

if __name__ == "__main__":
    from schema_watcher.schema_watcher import list_delta_files
    run_workflow()