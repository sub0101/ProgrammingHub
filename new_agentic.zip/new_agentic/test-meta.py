import os
import requests

# ---- Load from Environment Variables ----
OPENMETADATA_HOST ="http://127.0.0.1:8585"
OPENMETADATA_TOKEN="eyJraWQiOiJHYjM4OWEtOWY3Ni1nZGpzLWE5MmotMDI0MmJrOTQzNTYiLCJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJvcGVuLW1ldGFkYXRhLm9yZyIsInN1YiI6ImFkbWluIiwicm9sZXMiOlsiQWRtaW4iXSwiZW1haWwiOiJhZG1pbkBvcGVuLW1ldGFkYXRhLm9yZyIsImlzQm90IjpmYWxzZSwidG9rZW5UeXBlIjoiUEVSU09OQUxfQUNDRVNTIiwiaWF0IjoxNzUyNTYzMDgwLCJleHAiOjE3NjAzMzkwODB9.zAUR33kW29Kpyrue1-68nH09CaI0wL1qCDN13VbRI2a1sM6DcAZiNyV8jq-C7Vlr4UI_rFmaLf2TNTRK60u2so94HDA_Zf0WmDhEVOkqp3U6K0tKYpK-uUuG9uaYmXgMAQD0ouE04H_CTgI2QqG_7yK3AubbBNkFhB8B6hzhtrBLxzCaCHxPRfytgIny8NO-4kvqrKj6OGP2gZXtcc3zAp7DhvDMGfYn_M1VG7RMpE9sOvmKYfvqF_vSvtDUQE_1k2CIj3OrHx2gsrOW79uu8U24hN9NfruaCb_chV4RtQnBRixDVpmnI77ZIFqkQ9KDLp7flXKIBy3H9IXPg1XI0g"

HIVE_SERVICE = "customers"
HIVE_DATABASE = "default.lakehouse"
# TABLE_NAME = os.getenv("TABLE_NAME")
TABLE_NAME = "user_data"

if not all([OPENMETADATA_HOST, OPENMETADATA_TOKEN, HIVE_SERVICE, HIVE_DATABASE, TABLE_NAME]):
    raise ValueError("❌ One or more environment variables are missing")

# ---- Compose FQN ----
FQN = f"{HIVE_SERVICE}.{HIVE_DATABASE}.{TABLE_NAME}"
URL = f"{OPENMETADATA_HOST}/api/v1/tables/name/{FQN}?fields=columns"

HEADERS = {
    "Content-Type": "application/json",
    "Authorization": f"Bearer {OPENMETADATA_TOKEN}"
}

# ---- Fetch Table Schema ----
response = requests.get(URL, headers=HEADERS)

if response.status_code == 200:
    data = response.json()
    columns = data.get("columns", [])
    print(f"\n📄 Schema for table `{FQN}`:")
    for col in columns:
        print(f"  - {col['name']} ({col['dataTypeDisplay']})")
else:
    print(f"❌ Failed to fetch schema. Status: {response.status_code}")
    print(response.text)
